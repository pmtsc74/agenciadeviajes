<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

include("conexion.php");

// Guardar nueva habitación
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['numero'])) {
    $cod_hotel = $_POST['cod_hotel'];
    $numero = $_POST['numero'];
    $tipo = $_POST['tipo'];
    $precio = $_POST['precio'];
    $estado = $_POST['estado'];

    $sql = "INSERT INTO habitaciones (cod_hotel, numero_habitacion, tipo, precio, estado)
            VALUES ('$cod_hotel', '$numero', '$tipo', '$precio', '$estado')";
    mysqli_query($conn, $sql);
    header("Location: habitaciones.php?hotel=$cod_hotel");
    exit();
}

$hoteles = mysqli_query($conn, "SELECT * FROM hoteles");
$hotel_filtro = $_GET['hotel'] ?? '';
$condicion = $hotel_filtro ? "WHERE h.cod_hotel = '$hotel_filtro'" : "";
$query = "SELECT h.*, ho.nombre as nombre_hotel, ho.pais 
          FROM habitaciones h 
          INNER JOIN hoteles ho ON h.cod_hotel = ho.cod_hotel $condicion";
$habitaciones = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Habitaciones</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .carousel-item img {
            height: 200px;
            object-fit: cover;
        }

        
    body.bg-habitaciones {
        background-image: url('imagenes/fondos/habitaciones.jpg');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
    }
    .container {
        background-color: rgba(255, 255, 255, 0.96);
        padding: 2rem;
        border-radius: 15px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
    }
    h3 {
        font-weight: bold;
        color: #333;
    }


    </style>
</head>
<body class="bg-habitaciones">
<body class="bg-light">
<div class="container py-4">
    <h3 class="mb-4">Gestión de Habitaciones</h3>

    <form method="GET" class="mb-4">
        <label class="form-label">Selecciona un hotel para ver sus habitaciones:</label>
        <div class="input-group">
            <select name="hotel" class="form-select" required onchange="this.form.submit()">
                <option value="">-- Elegir hotel --</option>
                <?php
                mysqli_data_seek($hoteles, 0);
                while($h = mysqli_fetch_assoc($hoteles)): ?>
                    <option value="<?= $h['cod_hotel'] ?>" <?= $hotel_filtro == $h['cod_hotel'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($h['nombre']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
            <button class="btn btn-outline-primary" type="submit">Ver</button>
        </div>
    </form>

    <?php if (!$hotel_filtro): ?>
        <div class="alert alert-info">Por favor selecciona un hotel para ver o agregar sus habitaciones.</div>
    <?php endif; ?>

    <?php if ($hotel_filtro): ?>
        <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#modalAgregar">+ Nueva Habitación</button>
    <?php endif; ?>

    <div class="row">
    <?php if (mysqli_num_rows($habitaciones) == 0): ?>
        <div class="alert alert-danger">No hay habitaciones registradas para este hotel.</div>
    <?php endif; ?>

    <?php while($hab = mysqli_fetch_assoc($habitaciones)):
        // Sanitizar el nombre del país (ej. "Costa Rica" -> "costa_rica", "México" -> "mexico")
        $pais = strtolower(iconv('UTF-8', 'ASCII//TRANSLIT', $hab['pais']));
        $pais = str_replace(' ', '_', $pais);

        $imagenes = [];
        for ($i = 1; $i <= 3; $i++) {
            $ruta = "imagenes/habitaciones/$pais/habitacion_" . $hab['numero_habitacion'] . "_$i.jpg";
            if (file_exists($ruta)) {
                $imagenes[] = $ruta;
            }
        }
        if (empty($imagenes)) {
            $imagenes[] = "imagenes/habitaciones/default.jpg";
        }

        $carouselId = "carousel" . $hab['id'];
    ?>
        <div class="col-md-4 mb-4">
            <div class="card habitacion-card shadow-sm">
                <!-- Carrusel de imágenes -->
                <div id="<?= $carouselId ?>" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <?php foreach ($imagenes as $index => $img): ?>
                            <div class="carousel-item <?= $index === 0 ? 'active' : '' ?>">
                                <img src="<?= $img . '?v=' . time() ?>" class="d-block w-100" alt="Imagen habitación <?= htmlspecialchars($hab['numero_habitacion']) ?>">
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <?php if (count($imagenes) > 1): ?>
                        <button class="carousel-control-prev" type="button" data-bs-target="#<?= $carouselId ?>" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Anterior</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#<?= $carouselId ?>" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Siguiente</span>
                        </button>
                    <?php endif; ?>
                </div>

                <!-- Detalles de la habitación -->
                <div class="card-body">
                    <h5 class="card-title">Habitación <?= htmlspecialchars($hab['numero_habitacion']) ?></h5>
                    <p class="card-text">
                        Tipo: <strong><?= htmlspecialchars($hab['tipo']) ?></strong><br>
                        Precio: <strong>$<?= number_format($hab['precio'], 2) ?></strong><br>
                        Estado: <?= htmlspecialchars($hab['estado']) ?>
                    </p>
                </div>
            </div>
        </div>
    <?php endwhile; ?>
    </div>
</div>

<!-- Modal agregar habitación -->
<div class="modal fade" id="modalAgregar" tabindex="-1">
    <div class="modal-dialog">
        <form method="POST" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Nueva Habitación</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="cod_hotel" value="<?= $hotel_filtro ?>">
                <div class="mb-2">
                    <label>Número de Habitación</label>
                    <input type="text" name="numero" class="form-control" required>
                </div>
                <div class="mb-2">
                    <label>Tipo</label>
                    <input type="text" name="tipo" class="form-control">
                </div>
                <div class="mb-2">
                    <label>Precio</label>
                    <input type="number" step="0.01" name="precio" class="form-control">
                </div>
                <div class="mb-2">
                    <label>Estado</label>
                    <select name="estado" class="form-select">
                        <option>Disponible</option>
                        <option>Ocupada</option>
                        <option>Mantenimiento</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary">Agregar</button>
            </div>
        </form>
    </div>
</div>

<!-- Botón Volver -->
<div class="mb-3">
    <a href="hoteles.php" class="btn btn-secondary">&larr; Volver a Hoteles</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
