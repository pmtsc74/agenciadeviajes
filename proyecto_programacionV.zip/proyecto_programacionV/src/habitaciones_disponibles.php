<?php
include("conexion.php");

$hotel = $_GET['hotel'];
$resultado = mysqli_query($conn, "SELECT * FROM habitaciones WHERE cod_hotel='$hotel' AND estado='Disponible'");

echo '<label>Habitación:</label>';
echo '<select name="habitacion_id" class="form-select" required>';
while ($h = mysqli_fetch_assoc($resultado)) {
    echo "<option value='{$h['id']}'>Habitación {$h['numero_habitacion']} ({$h['tipo']}) - $ {$h['precio']}</option>";
}
echo '</select>';
