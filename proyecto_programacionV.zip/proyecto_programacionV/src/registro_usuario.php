<?php
include("conexion.php");
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre_completo = trim($_POST["nombre_completo"]);
    $username = trim($_POST["username"]);
    $correo = trim($_POST["correo"]);
    $telefono = trim($_POST["telefono"]);
    $rol = $_POST["rol"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);

    $verificar = $conn->prepare("SELECT id FROM usuarios WHERE username = ?");
    $verificar->bind_param("s", $username);
    $verificar->execute();
    $verificar->store_result();

    if ($verificar->num_rows > 0) {
        $mensaje = "Este nombre de usuario ya está registrado.";
    } else {
        $sql = "INSERT INTO usuarios (nombre_completo, username, password, correo, telefono, rol) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssss", $nombre_completo, $username, $password, $correo, $telefono, $rol);

        if ($stmt->execute()) {
            $mensaje = "Usuario registrado exitosamente.";
        } else {
            $mensaje = "Error al registrar usuario.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro de Usuario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <div class="card mx-auto" style="max-width: 600px;">
        <div class="card-body">
            <h4 class="card-title text-center mb-4">Registro de Usuario</h4>
            <?php if ($mensaje): ?>
                <div class="alert alert-info"><?= $mensaje ?></div>
            <?php endif; ?>
            <form method="POST" action="">
                <div class="mb-3">
                    <label class="form-label">Nombre completo</label>
                    <input type="text" class="form-control" name="nombre_completo" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Cédula (Usuario)</label>
                    <input type="text" class="form-control" name="username" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Correo electrónico</label>
                    <input type="email" class="form-control" name="correo" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Teléfono</label>
                    <input type="text" class="form-control" name="telefono" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Rol</label>
                    <select class="form-select" name="rol" required>
                        <option value="Usuario">Usuario</option>
                        <option value="Administrador">Administrador</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Contraseña</label>
                    <input type="password" class="form-control" name="password" required>
                </div>
                <div class="d-grid">
                    <button type="submit" class="btn btn-success">Registrar Usuario</button>
                </div>
                <div class="text-center mt-3">
                    <a href="login.php" class="text-decoration-none">¿Ya tienes cuenta? Inicia sesión aquí</a>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>
