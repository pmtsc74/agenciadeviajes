<?php
// Conexión para Docker
$host = "mysql";
$user = "root"; 
$password = "root";
$database = "agencia_viajes";  // o "hotel_restaurante"

$conexion = new mysqli($host, $user, $password, $database);

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}
echo "Conectado exitosamente a la base de datos";
?>
