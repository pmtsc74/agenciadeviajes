<?php
session_start();
include("conexion.php");

$mensaje = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = trim($_POST["username"]);
    $clave = $_POST["password"];

    $sql = "SELECT * FROM usuarios WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows === 1) {
        $fila = $resultado->fetch_assoc();
        if (password_verify($clave, $fila['password'])) {
            $_SESSION['usuario'] = $fila['nombre_completo'];
            $_SESSION['rol'] = $fila['rol'];
            header("Location: bienvenida.php");
            exit();
        } else {
            $mensaje = "❌ Contraseña incorrecta.";
        }
    } else {
        $mensaje = "⚠️ Usuario no encontrado.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Iniciar Sesión - SkyExplorer Tours</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background: url('1999.png') no-repeat center center fixed;
            background-size: cover;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-card {
            background: rgba(255, 255, 255, 0.95);
            padding: 2rem;
            border-radius: 1rem;
            box-shadow: 0 0 20px rgba(0,0,0,0.2);
            max-width: 400px;
            width: 100%;
        }

        .form-control {
            border-radius: 0.5rem;
        }

        .btn-primary {
            border-radius: 0.5rem;
        }

        .login-title {
            font-weight: bold;
            color: #0d6efd;
        }

        .alert {
            font-size: 0.9rem;
        }
    </style>
</head>
<body>

<div class="login-card text-center">
    <h3 class="login-title mb-4"><i class="bi bi-shield-lock-fill"></i> Iniciar Sesión</h3>

    <?php if ($mensaje): ?>
        <div class="alert alert-danger"><?= $mensaje ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="mb-3 text-start">
            <label for="username" class="form-label">Usuario (Cédula)</label>
            <div class="input-group">
                <span class="input-group-text"><i class="bi bi-person-fill"></i></span>
                <input type="text" class="form-control" name="username" required autofocus>
            </div>
        </div>

        <div class="mb-3 text-start">
            <label for="password" class="form-label">Contraseña</label>
            <div class="input-group">
                <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                <input type="password" class="form-control" name="password" required>
            </div>
        </div>

        <button type="submit" class="btn btn-primary w-100">Ingresar</button>

        <div class="mt-3">
            <a href="registro_usuario.php" class="text-decoration-none">¿No tienes cuenta? Regístrate aquí</a>
        </div>
    </form>
</div>

</body>
</html>
