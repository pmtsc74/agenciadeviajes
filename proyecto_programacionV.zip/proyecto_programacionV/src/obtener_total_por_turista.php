<?php
include("conexion.php");

if (!isset($_GET['cod'])) {
    echo json_encode(["error" => "Código de turista no proporcionado."]);
    exit();
}

$cod_turista = intval($_GET['cod']);

// Total reserva hotel (solo reservas activas)
$sql_hotel = "SELECT SUM(total) AS total_hotel 
              FROM reserva_hotel 
              WHERE cod_turista = ? AND estado = 'Activa'";
$stmt_hotel = $conn->prepare($sql_hotel);
$stmt_hotel->bind_param("i", $cod_turista);
$stmt_hotel->execute();
$res_hotel = $stmt_hotel->get_result()->fetch_assoc();
$total_hotel = $res_hotel['total_hotel'] ?? 0.00;

// Total reserva vuelo (sumar precio del vuelo de las reservas de ese turista)
$sql_vuelo = "SELECT SUM(v.precio) AS total_vuelo
              FROM reserva_vuelo rv
              JOIN vuelos v ON rv.num_vuelo = v.num_vuelo
              WHERE rv.cod_turista = ?";
$stmt_vuelo = $conn->prepare($sql_vuelo);
$stmt_vuelo->bind_param("i", $cod_turista);
$stmt_vuelo->execute();
$res_vuelo = $stmt_vuelo->get_result()->fetch_assoc();
$total_vuelo = $res_vuelo['total_vuelo'] ?? 0.00;

// Sumar ambos
$total = $total_hotel + $total_vuelo;

// Devolver como JSON
echo json_encode(["total" => number_format($total, 2, '.', '')]);

$conn->close();
?>
