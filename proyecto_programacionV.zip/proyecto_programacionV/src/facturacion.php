<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}
require_once 'conexion.php';

// Insertar nueva factura
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['crear_factura'])) {
    $id_reserva = $_POST['id_reserva'];
    $tipo_reserva = $_POST['tipo_reserva'];
    $monto = $_POST['monto'];
    $cliente = trim($_POST['cliente']);
    $estado = $_POST['estado'];

    $sql = "INSERT INTO facturas (id_reserva, tipo_reserva, monto, estado, cliente) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isdss", $id_reserva, $tipo_reserva, $monto, $estado, $cliente);
    if ($stmt->execute()) {
        header("Location: facturacion.php");
        exit();
    } else {
        $error = "Error al crear la factura.";
    }
    $stmt->close();
}

// Obtener facturas
$facturas = $conn->query("SELECT * FROM facturas ORDER BY fecha DESC");

// Obtener reservas para seleccionar (unificar vuelos y hoteles)
$reservas = $conn->query("
    SELECT id, 'vuelo' AS tipo, id_destino FROM reservas_vuelo
    UNION ALL
    SELECT id, 'hotel' AS tipo, id_destino FROM reservas_hotel
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Facturación - SkyExplorer</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-white">
<div class="container mt-5">
    <h2 class="text-primary mb-4">Facturación</h2>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" class="bg-secondary p-4 rounded mb-5">
        <h5>Crear nueva factura</h5>
        <div class="mb-3">
            <label for="id_reserva" class="form-label">Reserva</label>
            <select name="id_reserva" id="id_reserva" class="form-select" required>
                <option value="">Seleccione una reserva</option>
                <?php while ($r = $reservas->fetch_assoc()): ?>
                    <option value="<?= $r['id'] ?>" data-tipo="<?= $r['tipo'] ?>">
                        <?= ucfirst($r['tipo']) ?> - ID: <?= $r['id'] ?> - Destino ID: <?= $r['id_destino'] ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="tipo_reserva" class="form-label">Tipo de Reserva</label>
            <input type="text" id="tipo_reserva" name="tipo_reserva" class="form-control" readonly required>
        </div>

        <div class="mb-3">
            <label for="monto" class="form-label">Monto (USD)</label>
            <input type="number" name="monto" id="monto" class="form-control" step="0.01" required>
        </div>

        <div class="mb-3">
            <label for="cliente" class="form-label">Nombre del Cliente</label>
            <input type="text" name="cliente" id="cliente" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="estado" class="form-label">Estado</label>
            <select name="estado" id="estado" class="form-select" required>
                <option value="pendiente">Pendiente</option>
                <option value="pagada">Pagada</option>
                <option value="anulada">Anulada</option>
            </select>
        </div>

        <button type="submit" name="crear_factura" class="btn btn-success">Crear Factura</button>
    </form>

    <h5>Facturas Generadas</h5>
    <table class="table table-dark table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Reserva ID</th>
                <th>Tipo Reserva</th>
                <th>Monto (USD)</th>
                <th>Cliente</th>
                <th>Estado</th>
                <th>Fecha</th>
            </tr>
        </thead>
        <tbody>
            <?php while($f = $facturas->fetch_assoc()): ?>
                <tr>
                    <td><?= $f['id'] ?></td>
                    <td><?= $f['id_reserva'] ?></td>
                    <td><?= ucfirst($f['tipo_reserva']) ?></td>
                    <td>$<?= number_format($f['monto'], 2) ?></td>
                    <td><?= htmlspecialchars($f['cliente']) ?></td>
                    <td><?= ucfirst($f['estado']) ?></td>
                    <td><?= $f['fecha'] ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <a href="menu_principal.php" class="btn btn-outline-light mt-4">← Volver al Menú</a>
</div>

<script>
// Actualizar el campo tipo_reserva según la reserva seleccionada
document.getElementById('id_reserva').addEventListener('change', function() {
    const selectedOption = this.options[this.selectedIndex];
    const tipo = selectedOption.getAttribute('data-tipo') || '';
    document.getElementById('tipo_reserva').value = tipo;
});
</script>

</body>
</html>
