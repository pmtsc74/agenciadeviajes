<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

include("conexion.php");

// Acciones de estado
if (isset($_GET['accion']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $accion = $_GET['accion'];

    if ($accion == 'finalizar') {
        mysqli_query($conn, "UPDATE reserva_hotel SET estado='Finalizada' WHERE id='$id'");
    } elseif ($accion == 'cancelar') {
        mysqli_query($conn, "UPDATE reserva_hotel SET estado='Cancelada' WHERE id='$id'");
        $res = mysqli_query($conn, "SELECT habitacion_id FROM reserva_hotel WHERE id='$id'");
        $row = mysqli_fetch_assoc($res);
        mysqli_query($conn, "UPDATE habitaciones SET estado='Disponible' WHERE id='{$row['habitacion_id']}'");
    }

    header("Location: listar_reservas.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Listado de Reservas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body.bg-reservas {
            background-image: url('imagenes/fondos/reservas_listado.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }
        .tabla-glass {
            background-color: rgba(255, 255, 255, 0.96);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 25px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body class="bg-reservas">
<div class="container py-4">
    <div class="tabla-glass">
        <h3 class="mb-4 text-center">Reservaciones Actuales</h3>

        <table class="table table-striped table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Cliente</th>
                    <th>Hotel</th>
                    <th>Habitación</th>
                    <th>Fechas</th>
                    <th>Huéspedes</th>
                    <th>Régimen</th>
                    <th>Código</th>
                    <th>Total</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $sql = "SELECT r.*, 
                           t.nombre AS nombre_turista, 
                           t.apellidos,
                           h.nombre AS nombre_hotel,
                           hb.numero_habitacion
                    FROM reserva_hotel r
                    JOIN turistas t ON r.cod_turista = t.cod_turista
                    JOIN hoteles h ON r.cod_hotel = h.cod_hotel
                    JOIN habitaciones hb ON r.habitacion_id = hb.id
                    ORDER BY r.fecha_llegada DESC";

            $reservas = mysqli_query($conn, $sql);
            while ($r = mysqli_fetch_assoc($reservas)):
            ?>
                <tr>
                    <td><?= $r['id'] ?></td>
                    <td><?= $r['nombre_turista'] . ' ' . $r['apellidos'] ?></td>
                    <td><?= $r['nombre_hotel'] ?></td>
                    <td><?= $r['numero_habitacion'] ?></td>
                    <td><?= $r['fecha_llegada'] ?> <br> al <br> <?= $r['fecha_partida'] ?></td>
                    <td><?= $r['adultos'] ?> adulto(s)<br><?= $r['ninos'] ?> niño(s)</td>
                    <td><?= $r['regimen'] ?></td>
                    <td><?= $r['codigo_reserva'] ?></td>
                    <td>$<?= $r['total'] ?></td>
                    <td>
                        <span class="badge bg-<?= 
                            $r['estado'] == 'Activa' ? 'primary' : 
                            ($r['estado'] == 'Finalizada' ? 'success' : 'danger') ?>">
                            <?= $r['estado'] ?>
                        </span>
                    </td>
                    <td>
                        <?php if ($r['estado'] == 'Activa'): ?>
                            <a href="?accion=finalizar&id=<?= $r['id'] ?>" class="btn btn-sm btn-success mb-1">Finalizar</a>
                            <a href="?accion=cancelar&id=<?= $r['id'] ?>" class="btn btn-sm btn-danger">Cancelar</a>
                        <?php else: ?>
                            <span class="text-muted">Sin acciones</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>

        <div class="text-end mt-3">
            <a href="menu.php" class="btn btn-outline-dark">← Volver al menú</a>
        </div>
    </div>
</div>
</body>
</html>
