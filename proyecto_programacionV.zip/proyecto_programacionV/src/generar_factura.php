<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}
include("conexion.php");

// Consulta para obtener la última factura con datos de cliente, vuelo y hotel
$sql = "
SELECT f.*, 
       CONCAT(t.nombre, ' ', t.apellidos) AS nombre_cliente, 
       v.destino AS destino_viaje_nombre,
       h.nombre AS hotel_nombre
FROM facturas f
LEFT JOIN turistas t ON f.cliente = CONCAT(t.nombre, ' ', t.apellidos)
LEFT JOIN reserva_hotel rh ON rh.codigo_reserva = f.id_reserva AND f.tipo_reserva = 'hotel' AND rh.cod_turista = t.cod_turista
LEFT JOIN hoteles h ON rh.cod_hotel = h.cod_hotel
LEFT JOIN reserva_vuelo rv ON rv.codigo_reserva = f.id_reserva AND f.tipo_reserva = 'vuelo' AND rv.cod_turista = t.cod_turista
LEFT JOIN vuelos v ON rv.num_vuelo = v.num_vuelo
ORDER BY f.fecha DESC
LIMIT 1
";

$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Error en la consulta: " . mysqli_error($conn));
}

$factura = mysqli_fetch_assoc($result);

if (!$factura) {
    echo "<p>No hay ninguna factura registrada.</p>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>SkyExplorer Tour - Boleto de Viaje #<?php echo htmlspecialchars($factura['id']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            background: #f7f9fc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #212529;
            padding: 40px 0;
        }
        .ticket {
            max-width: 650px;
            margin: 0 auto;
            background: #fff;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
            padding: 30px 40px;
            border-top: 8px solid #0d6efd;
            position: relative;
        }
        .ticket::before, .ticket::after {
            content: "";
            position: absolute;
            width: 40px;
            height: 40px;
            background: #f7f9fc;
            border-radius: 50%;
            top: 50%;
            transform: translateY(-50%);
            z-index: 10;
        }
        .ticket::before {
            left: -20px;
            box-shadow: 10px 0 0 #fff;
        }
        .ticket::after {
            right: -20px;
            box-shadow: -10px 0 0 #fff;
        }
        .agency-name {
            font-size: 2rem;
            font-weight: 700;
            color: #0d6efd;
            text-align: center;
            margin-bottom: 10px;
            letter-spacing: 2px;
        }
        .ticket-title {
            text-align: center;
            font-size: 1.25rem;
            color: #6c757d;
            margin-bottom: 30px;
            text-transform: uppercase;
            letter-spacing: 1.5px;
        }
        .section {
            margin-bottom: 25px;
        }
        .label {
            font-weight: 600;
            color: #495057;
            font-size: 0.95rem;
            margin-bottom: 4px;
        }
        .value {
            font-size: 1.15rem;
            font-weight: 500;
            color: #212529;
        }
        .flex-row {
            display: flex;
            justify-content: space-between;
            gap: 30px;
        }
        .flex-col {
            flex: 1;
        }
        .price {
            font-size: 2.5rem;
            font-weight: 700;
            color: #ffc107;
            text-align: center;
            margin-top: 15px;
            letter-spacing: 1.2px;
            font-family: 'Courier New', Courier, monospace;
        }
        .btn-print, .btn-back {
            display: inline-block;
            font-weight: 600;
            color: #fff;
            background-color: #0d6efd;
            border: none;
            padding: 12px 25px;
            border-radius: 50px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s ease;
            margin: 5px 10px 0 10px;
            user-select: none;
        }
        .btn-print:hover, .btn-back:hover {
            background-color: #0a58ca;
            color: #fff;
        }
        .footer-buttons {
            text-align: center;
            margin-top: 35px;
        }
        @media print {
            body {
                background: none;
                padding: 0;
            }
            .ticket {
                box-shadow: none;
                border: none;
                max-width: 100%;
                border-top: 4px solid #0d6efd;
                border-radius: 0;
                padding: 0;
            }
            .btn-print, .btn-back {
                display: none !important;
            }
        }
    </style>
</head>
<body>
    <div class="ticket">
        <div class="agency-name">SkyExplorer Tour</div>
        <div class="ticket-title">Boleto de Viaje</div>

        <div class="section flex-row">
            <div class="flex-col">
                <div class="label">Número de Factura</div>
                <div class="value"><?php echo htmlspecialchars($factura['id']); ?></div>
            </div>
            <div class="flex-col">
                <div class="label">Fecha y Hora</div>
                <div class="value"><?php echo date('d/m/Y H:i', strtotime($factura['fecha'])); ?></div>
            </div>
        </div>

        <div class="section flex-row">
            <div class="flex-col">
                <div class="label">Cliente</div>
                <div class="value"><?php echo htmlspecialchars($factura['nombre_cliente'] ?? $factura['cliente']); ?></div>
            </div>
            <div class="flex-col">
                <div class="label">Estado</div>
                <div class="value"><?php echo ucfirst(htmlspecialchars($factura['estado'])); ?></div>
            </div>
        </div>

        <div class="section flex-row">
            <div class="flex-col">
                <div class="label">Destino del Viaje</div>
                <div class="value"><?php echo htmlspecialchars($factura['destino_viaje_nombre'] ?? $factura['destino_viaje']); ?></div>
            </div>
            <div class="flex-col">
                <div class="label">Hotel de Hospedaje</div>
                <div class="value"><?php echo htmlspecialchars($factura['hotel_nombre'] ?? 'N/A'); ?></div>
            </div>
        </div>

        <div class="section">
            <div class="label text-center">Monto Total</div>
            <div class="price">$<?php echo number_format($factura['monto'], 2); ?></div>
        </div>

        <div class="footer-buttons">
            <button onclick="window.print()" class="btn-print">🖨️ Imprimir</button>
            <a href="menu.php" class="btn-back">← Volver al menú</a>
        </div>
    </div>
</body>
</html>
