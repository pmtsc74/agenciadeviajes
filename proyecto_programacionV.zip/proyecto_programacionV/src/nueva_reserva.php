<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

include("conexion.php");

// Guardar reservación
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cod_turista = $_POST['cod_turista'];
    $cod_hotel = $_POST['cod_hotel'];
    $habitacion_id = $_POST['habitacion_id'];
    $regimen = $_POST['regimen'];
    $fecha_llegada = $_POST['fecha_llegada'];
    $fecha_partida = $_POST['fecha_partida'];
    $codigo_reserva = $_POST['codigo_reserva'];
    $total = $_POST['total'];
    $adultos = $_POST['adultos'];
    $ninos = $_POST['ninos'];

    $sql = "INSERT INTO reserva_hotel (
                cod_turista, cod_hotel, habitacion_id, regimen,
                fecha_llegada, fecha_partida, codigo_reserva,
                total, estado, adultos, ninos
            ) VALUES (
                '$cod_turista', '$cod_hotel', '$habitacion_id', '$regimen',
                '$fecha_llegada', '$fecha_partida', '$codigo_reserva',
                '$total', 'Activa', '$adultos', '$ninos'
            )";
    mysqli_query($conn, $sql);

    mysqli_query($conn, "UPDATE habitaciones SET estado='Ocupada' WHERE id='$habitacion_id'");

    header("Location: listar_reservas.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registrar Nueva Reservación</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body.bg-reserva {
            background-image: url('imagenes/fondos/reserva.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }
        .formulario-glass {
            background-color: rgba(255, 255, 255, 0.96);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.25);
        }
    </style>
    <script>
        function cargarHabitaciones(hotelId) {
            const xhr = new XMLHttpRequest();
            xhr.open("GET", "habitaciones_disponibles.php?hotel=" + hotelId, true);
            xhr.onload = function () {
                document.getElementById("habitacionesContainer").innerHTML = this.responseText;
            };
            xhr.send();
        }

        function generarCodigo() {
            const r = Math.random().toString(36).substring(2, 8).toUpperCase();
            document.getElementById("codigo").value = r;
        }
    </script>
</head>
<body class="bg-reserva">
<div class="container py-4">
    <h3 class="mb-4 text-white text-center">Registrar Nueva Reservación</h3>

    <form method="POST" class="formulario-glass">
        <!-- Cliente y Hotel -->
        <div class="row mb-3">
            <div class="col-md-6">
                <label>Cliente:</label>
                <select name="cod_turista" class="form-select" required>
                    <?php
                    $clientes = mysqli_query($conn, "SELECT * FROM turistas");
                    while ($c = mysqli_fetch_assoc($clientes)) {
                        echo "<option value='{$c['cod_turista']}'>{$c['nombre']} {$c['apellidos']}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="col-md-6">
                <label>Hotel:</label>
                <select name="cod_hotel" class="form-select" onchange="cargarHabitaciones(this.value)" required>
                    <option value="">-- Selecciona un hotel --</option>
                    <?php
                    $hoteles = mysqli_query($conn, "SELECT * FROM hoteles");
                    while ($h = mysqli_fetch_assoc($hoteles)) {
                        echo "<option value='{$h['cod_hotel']}'>{$h['nombre']}</option>";
                    }
                    ?>
                </select>
            </div>
        </div>

        <!-- Habitaciones disponibles -->
        <div class="mb-3" id="habitacionesContainer">
            <label>Habitación:</label>
            <select name="habitacion_id" class="form-select" disabled>
                <option value="">Seleccione un hotel primero</option>
            </select>
        </div>

        <!-- Fechas, regimen -->
        <div class="row mb-3">
            <div class="col-md-4">
                <label>Régimen:</label>
                <select name="regimen" class="form-select">
                    <option value="completa">Pensión Completa</option>
                    <option value="media">Media Pensión</option>
                    <option value="solo alojamiento">Solo Alojamiento</option>
                </select>
            </div>
            <div class="col-md-4">
                <label>Fecha de llegada:</label>
                <input type="date" name="fecha_llegada" class="form-control" required>
            </div>
            <div class="col-md-4">
                <label>Fecha de salida:</label>
                <input type="date" name="fecha_partida" class="form-control" required>
            </div>
        </div>

        <!-- Adultos y niños -->
        <div class="row mb-3">
            <div class="col-md-3">
                <label>Adultos:</label>
                <input type="number" name="adultos" class="form-control" value="1" min="1" required>
            </div>
            <div class="col-md-3">
                <label>Niños:</label>
                <input type="number" name="ninos" class="form-control" value="0" min="0" required>
            </div>
        </div>

        <!-- Código y total -->
        <div class="row mb-3">
            <div class="col-md-4">
                <label>Código de Reserva:</label>
                <input type="text" name="codigo_reserva" id="codigo" class="form-control" required readonly>
                <button type="button" onclick="generarCodigo()" class="btn btn-sm btn-secondary mt-1">Generar</button>
            </div>
            <div class="col-md-4">
                <label>Total (USD):</label>
                <input type="number" step="0.01" name="total" class="form-control" required>
            </div>
        </div>

        <div class="text-end">
            <button class="btn btn-success">Registrar Reserva</button>
            <a href="menu.php" class="btn btn-outline-dark ms-2">← Volver al Menú</a>
        </div>
    </form>

    
</div>


<script>
    function calcularTotal() {
    const habitacionId = document.querySelector("select[name='habitacion_id']").value;
    const fechaLlegada = document.querySelector("input[name='fecha_llegada']").value;
    const fechaPartida = document.querySelector("input[name='fecha_partida']").value;

    if (!habitacionId || !fechaLlegada || !fechaPartida) return;

    const fecha1 = new Date(fechaLlegada);
    const fecha2 = new Date(fechaPartida);
    const diffTime = fecha2 - fecha1;
    const noches = diffTime / (1000 * 60 * 60 * 24);

    if (noches <= 0) return;

    // Obtener precio de la habitación
    const xhr = new XMLHttpRequest();
    xhr.open("GET", "precio_habitacion.php?id=" + habitacionId, true);
    xhr.onload = function () {
        if (this.status === 200) {
            const precio = parseFloat(this.responseText);
            if (!isNaN(precio)) {
                const total = precio * noches;
                document.querySelector("input[name='total']").value = total.toFixed(2);
            }
        }
    };
    xhr.send();
}

// Escuchar cambios
document.addEventListener('DOMContentLoaded', function () {
    document.querySelector("input[name='fecha_llegada']").addEventListener('change', calcularTotal);
    document.querySelector("input[name='fecha_partida']").addEventListener('change', calcularTotal);

    // También si ya está visible el select de habitación
    document.addEventListener('change', function (e) {
        if (e.target.name === 'habitacion_id') {
            calcularTotal();
        }
    });
});

</script>
</body>
</html>
