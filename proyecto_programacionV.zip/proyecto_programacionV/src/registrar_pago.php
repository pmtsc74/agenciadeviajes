<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}
include("conexion.php");

// Guardar el pago
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cod_turista = $_POST['cod_turista'];
    $metodo_pago = $_POST['metodo_pago'];
    $monto = $_POST['monto'];
    $fecha_pago = $_POST['fecha_pago'];
    $banco = $_POST['banco'];
    $numero_transferencia = $_POST['numero_transferencia'];

    // Obtener nombre del cliente
    $res = mysqli_query($conn, "SELECT CONCAT(nombre, ' ', apellidos) AS nombre_completo FROM turistas WHERE cod_turista = $cod_turista");
    $cliente = mysqli_fetch_assoc($res)['nombre_completo'] ?? 'Desconocido';

    // Insertar en la tabla facturas (sin id_reserva ni tipo_reserva)
    $stmt_factura = $conn->prepare("INSERT INTO facturas (fecha, monto, estado, cliente) VALUES (NOW(), ?, 'pagada', ?)");
    $stmt_factura->bind_param("ds", $monto, $cliente);
    $stmt_factura->execute();
    $stmt_factura->close();

    // Insertar en tabla pagos (sin id_reserva ni tipo_reserva)
    $stmt_pago = $conn->prepare("INSERT INTO pagos (cod_turista, metodo_pago, monto, fecha_pago, banco, numero_transferencia)
                                VALUES (?, ?, ?, ?, ?, ?)");
    $stmt_pago->bind_param("isdsss", $cod_turista, $metodo_pago, $monto, $fecha_pago, $banco, $numero_transferencia);
    $stmt_pago->execute();
    $stmt_pago->close();

   // Reemplaza esta parte:
    // header("Location: generar_factura.php");
    // exit();

// Por esta:
    echo "<!DOCTYPE html>
    <html lang='es'>
    <head>
        <meta charset='UTF-8'>
        <title>Pago Realizado</title>
        <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>
    </head>
    <body class='bg-light d-flex justify-content-center align-items-center' style='height: 100vh;'>
        <div class='text-center p-5 bg-white rounded shadow'>
            <h2 class='text-success mb-4'>✅ Pago realizado con éxito</h2>
            <a href='generar_factura.php' class='btn btn-primary'>Ver Factura</a>
        </div>
    </body>
    </html>";
    exit();

}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registrar Pago</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body.bg-pago {
            background-image: url('imagenes/fondos/pago.jpg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }
        .form-container {
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 10px;
            padding: 30px;
            max-width: 600px;
            margin: auto;
            box-shadow: 0 0 20px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body class="bg-pago">
<div class="container py-5">
    <div class="form-container">
        <h3 class="mb-4 text-center">💳 Registrar Pago</h3>
        <form method="POST">
            <!-- Cliente -->
            <div class="mb-3">
                <label>Cliente:</label>
                <select name="cod_turista" class="form-select" id="clienteSelect" required onchange="obtenerMontoPorTurista(this.value)">
                    <option value="">-- Selecciona un cliente --</option>
                    <?php
                    $clientes = mysqli_query($conn, "SELECT cod_turista, nombre, apellidos FROM turistas");
                    while ($c = mysqli_fetch_assoc($clientes)) {
                        echo "<option value='{$c['cod_turista']}'>{$c['nombre']} {$c['apellidos']}</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- Monto -->
            <div class="mb-3">
                <label>Monto total (USD):</label>
                <input type="number" step="0.01" name="monto" id="monto" class="form-control" required readonly>
            </div>

            <!-- Método de pago -->
            <div class="mb-3">
                <label>Método de pago:</label>
                <select name="metodo_pago" class="form-select" required>
                    <option value="Efectivo">Efectivo</option>
                    <option value="Tarjeta">Tarjeta</option>
                    <option value="Transferencia">Transferencia</option>
                </select>
            </div>

            <!-- Fecha de pago -->
            <div class="mb-3">
                <label>Fecha de pago:</label>
                <input type="date" name="fecha_pago" class="form-control" required>
            </div>

            <!-- Banco -->
            <div class="mb-3">
                <label>Banco (opcional):</label>
                <input type="text" name="banco" class="form-control">
            </div>

            <!-- Número de transferencia -->
            <div class="mb-3">
                <label>Número de transferencia (opcional):</label>
                <input type="text" name="numero_transferencia" class="form-control">
            </div>

            <!-- Botones -->
            <div class="text-center">
                <button class="btn btn-primary">Registrar Pago</button>
                <a href="menu.php" class="btn btn-secondary ms-2">← Volver al menú</a>
            </div>
        </form>
    </div>
</div>

<script>
// Función para traer el monto total según cliente
function obtenerMontoPorTurista(cod_turista) {
    if (!cod_turista) {
        document.getElementById('monto').value = '';
        return;
    }

    fetch('obtener_total_por_turista.php?cod=' + cod_turista)
        .then(response => response.json())
        .then(data => {
            if (data.total !== undefined) {
                document.getElementById('monto').value = data.total;
            } else {
                document.getElementById('monto').value = '0.00';
            }
        })
        .catch(error => {
            console.error('Error al obtener el monto:', error);
            document.getElementById('monto').value = '0.00';
        });
}
</script>
</body>
</html>
