<?php
include("conexion.php");

$id = $_POST['id'];
$tipo = $_POST['tipo'];
$precio = $_POST['precio'];
$estado = $_POST['estado'];

$sql = "UPDATE habitaciones SET tipo='$tipo', precio='$precio', estado='$estado' WHERE id='$id'";
mysqli_query($conn, $sql);

header("Location: habitaciones.php");
