<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}
require_once 'conexion.php'; // Archivo donde está la conexión MySQLi

// Insertar nuevo destino
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['agregar'])) {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $pais = $_POST['pais'];
    $precio = $_POST['precio'];

    $sql = "INSERT INTO destinos (nombre, descripcion, pais, precio) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssd", $nombre, $descripcion, $pais, $precio);
    $stmt->execute();
    $stmt->close();
    header("Location: gestion_destinos.php");
    exit();
}

// Eliminar destino
if (isset($_GET['eliminar'])) {
    $id = $_GET['eliminar'];
    $sql = "DELETE FROM destinos WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: gestion_destinos.php");
    exit();
}

// Obtener lista de destinos
$resultado = $conn->query("SELECT * FROM destinos ORDER BY fecha_creacion DESC");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Destinos - SkyExplorer Tours</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-white">
<div class="container mt-5">
    <h2 class="mb-4 text-primary">Gestión de Destinos</h2>

    <form method="POST" class="row g-3 bg-secondary p-4 rounded">
        <h5>Agregar nuevo destino</h5>
        <div class="col-md-6">
            <label>Nombre</label>
            <input type="text" name="nombre" class="form-control" required>
        </div>
        <div class="col-md-6">
            <label>País</label>
            <input type="text" name="pais" class="form-control" required>
        </div>
        <div class="col-md-12">
            <label>Descripción</label>
            <textarea name="descripcion" class="form-control" rows="3"></textarea>
        </div>
        <div class="col-md-4">
            <label>Precio (USD)</label>
            <input type="number" name="precio" class="form-control" step="0.01" required>
        </div>
        <div class="col-md-12 mt-3">
            <button type="submit" name="agregar" class="btn btn-success">Agregar Destino</button>
        </div>
    </form>

    <hr class="bg-white my-5">

    <h5>Lista de destinos registrados</h5>
    <table class="table table-dark table-striped mt-3">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>País</th>
                <th>Precio</th>
                <th>Fecha</th>
                <th>Acción</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = $resultado->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id']; ?></td>
                    <td><?= htmlspecialchars($row['nombre']); ?></td>
                    <td><?= htmlspecialchars($row['pais']); ?></td>
                    <td>$<?= number_format($row['precio'], 2); ?></td>
                    <td><?= $row['fecha_creacion']; ?></td>
                    <td>
                        <a href="?eliminar=<?= $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Eliminar destino?')">Eliminar</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <a href="menu_principal.php" class="btn btn-outline-light mt-4">← Volver al Menú</a>
</div>
</body>
</html>
