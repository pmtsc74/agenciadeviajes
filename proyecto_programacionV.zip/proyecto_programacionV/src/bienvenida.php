<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Bienvenido a SkyExplorer Tour</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            overflow: hidden;
            font-family: 'Segoe UI', sans-serif;
        }

        /* Video de fondo */
        #background-video {
            position: fixed;
            top: 0;
            left: 0;
            min-width: 100%;
            min-height: 100%;
            object-fit: cover;
            z-index: -1;
        }

        .welcome-container {
            background-color: rgba(0, 0, 0, 0.55);
            padding: 3rem;
            border-radius: 1rem;
            text-align: center;
            max-width: 600px;
            animation: fadeIn 1.5s ease-in-out;
            color: white;
        }

        .welcome-container h1 {
            font-size: 3rem;
            font-weight: bold;
            margin-bottom: 1rem;
            color: #0dcaf0;
        }

        .welcome-container p {
            font-size: 1.2rem;
            margin-bottom: 2rem;
        }

        .btn-enter {
            padding: 0.75rem 2rem;
            font-size: 1.1rem;
            border-radius: 0.5rem;
        }

        /* Animación de eslogan */
        .slogan {
            font-size: 1.2rem;
            color: #ffc107;
            margin-bottom: 20px;
            animation: fadeInText 5s ease-in-out infinite;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeInText {
            0% { opacity: 0; transform: translateY(20px); }
            50% { opacity: 1; transform: translateY(0); }
            100% { opacity: 0; transform: translateY(-20px); }
        }

        @media (max-width: 576px) {
            .welcome-container {
                padding: 2rem;
            }

            .welcome-container h1 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>

<!-- 🎥 Video de fondo -->
<video autoplay muted loop id="background-video">
    <source src="bg_video.mp4" type="video/mp4">
    Tu navegador no soporta video HTML5.
</video>

<!-- 🌍 Contenido principal -->
<div class="d-flex justify-content-center align-items-center vh-100">
    <div class="welcome-container shadow-lg">
        <h1><i class="bi bi-globe2"></i> SkyExplorer Tour</h1>
        <div class="slogan">Descubre el mundo... Vive la experiencia SkyExplorer</div>
        <p>Tu aventura comienza aquí.</p>
        <a href="menu.php" class="btn btn-primary btn-enter">
            <i class="bi bi-box-arrow-in-right"></i> Entrar
        </a>
    </div>
</div>

</body>
</html>
