<?php
$conexion = new mysqli("localhost", "root", "", "agencia_viajes");
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Reporte Detallado por Turista</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        /* Video de fondo */
        #video-background {
            position: fixed;
            right: 0;
            bottom: 0;
            min-width: 100%;
            min-height: 100%;
            width: auto;
            height: auto;
            z-index: -1;
            object-fit: cover;
            filter: brightness(0.6);
        }

        /* Contenedor para el contenido encima del video */
        .content-container {
            position: relative;
            z-index: 1;
            background-color: rgba(255, 255, 255, 0.85);
            padding: 40px;
            border-radius: 12px;
            max-width: 1200px;
            margin: 60px auto 80px auto;
            box-shadow: 0 8px 24px rgba(0,0,0,0.3);
        }

        /* Ajustes visuales del body sin fondo, para que no tape el video */
        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #212529;
            background: none;
        }

        h1.text-center {
            font-weight: 800;
            color: #003366;
            margin-bottom: 50px;
            text-shadow: 1px 1px 4px rgba(0,0,0,0.6);
        }

        .card-title {
            font-weight: 700;
            color: #003366;
        }

        .table thead th {
            background-color: #0d6efd;
            color: white;
        }

        .summary {
            font-weight: 600;
            font-size: 1.1rem;
        }

        .balance-positive {
            color: green;
            font-weight: 700;
        }

        .balance-negative {
            color: red;
            font-weight: 700;
        }

        .payment-status {
            font-size: 1.1rem;
        }

        small.text-muted {
            font-weight: normal;
            font-size: 0.85em;
        }

        /* Scrollbar para mejorar experiencia */
        ::-webkit-scrollbar {
            width: 8px;
        }
        ::-webkit-scrollbar-thumb {
            background: #0d6efd;
            border-radius: 4px;
        }
    </style>
</head>
<body>

    <!-- Video de fondo -->
    <video autoplay muted loop id="video-background">
        <source src="fondo_video.mp4" type="video/mp4">
        Tu navegador no soporta video de fondo.
    </video>

    <!-- Contenido principal -->
    <div class="content-container">
        <div class="container py-5">
            <h1 class="text-center">Reporte Detallado por Turista</h1>

            <?php
            $sql_turistas = "SELECT * FROM turistas";
            $res_turistas = $conexion->query($sql_turistas);

            while ($turista = $res_turistas->fetch_assoc()):
                $id_turista = (int)$turista['cod_turista'];
                echo "<div class='card mb-5 shadow'>";
                echo "<div class='card-body'>";
                echo "<h4 class='card-title'>🧑 {$turista['nombre']} {$turista['apellidos']}</h4>";
                echo "<p><strong>Dirección:</strong> {$turista['direccion']}<br><strong>Teléfono:</strong> {$turista['telefono']}</p>";

                // --- Reservas de Vuelo ---
                $sql_vuelo = "
                    SELECT rv.*, v.destino, v.empresa, v.precio AS precio_vuelo 
                    FROM reserva_vuelo rv 
                    LEFT JOIN vuelos v ON rv.num_vuelo = v.num_vuelo 
                    WHERE rv.cod_turista = $id_turista
                ";
                $vuelo = $conexion->query($sql_vuelo);

                $total_vuelos = 0;
                if ($vuelo->num_rows > 0) {
                    echo "<h5>✈️ Reserva de Vuelo</h5>";
                    echo "<table class='table table-bordered'>";
                    echo "<thead><tr><th>Vuelo</th><th>Destino</th><th>Empresa</th><th>Clase</th><th>Salida</th><th>Regreso</th><th>Código</th><th>Precio (USD)</th></tr></thead><tbody>";
                    while ($v = $vuelo->fetch_assoc()) {
                        $precio_vuelo = floatval($v['precio_vuelo']);
                        $total_vuelos += $precio_vuelo;
                        echo "<tr>
                                <td>{$v['num_vuelo']}</td>
                                <td>{$v['destino']}</td>
                                <td>{$v['empresa']}</td>
                                <td>{$v['clase']}</td>
                                <td>{$v['fecha_salida']}</td>
                                <td>{$v['fecha_regreso']}</td>
                                <td>{$v['codigo_reserva']}</td>
                                <td class='text-end'>\$" . number_format($precio_vuelo, 2) . "</td>
                              </tr>";
                    }
                    echo "</tbody></table>";
                }

                // --- Reservas de Hotel ---
                $sql_hotel = "
                    SELECT rh.*, h.nombre AS hotel, hb.precio AS precio_habitacion 
                    FROM reserva_hotel rh 
                    LEFT JOIN hoteles h ON rh.cod_hotel = h.cod_hotel 
                    LEFT JOIN habitaciones hb ON rh.habitacion_id = hb.id
                    WHERE rh.cod_turista = $id_turista
                ";
                $hotel = $conexion->query($sql_hotel);

                $total_hoteles = 0;
                if ($hotel->num_rows > 0) {
                    echo "<h5>🏨 Reserva de Hotel</h5>";
                    echo "<table class='table table-bordered'>";
                    echo "<thead><tr><th>Hotel</th><th>Régimen</th><th>Llegada</th><th>Salida</th><th>Código</th><th>Precio Total (USD)</th></tr></thead><tbody>";
                    while ($h = $hotel->fetch_assoc()) {
                        $precio_noche = floatval($h['precio_habitacion']);
                        $fecha_llegada = new DateTime($h['fecha_llegada']);
                        $fecha_partida = new DateTime($h['fecha_partida']);
                        $interval = $fecha_llegada->diff($fecha_partida);
                        $noches = $interval->days;

                        $total_reserva = $precio_noche * $noches;
                        $total_hoteles += $total_reserva;

                        echo "<tr>
                                <td>{$h['hotel']}</td>
                                <td>{$h['regimen']}</td>
                                <td>{$h['fecha_llegada']}</td>
                                <td>{$h['fecha_partida']}</td>
                                <td>{$h['codigo_reserva']}</td>
                                <td class='text-end'>\$" . number_format($total_reserva, 2) . " <small class='text-muted'>({$noches} noche(s) × \$" . number_format($precio_noche, 2) . ")</small></td>
                              </tr>";
                    }
                    echo "</tbody></table>";
                }

                $total_reservas = $total_vuelos + $total_hoteles;

                // --- Pagos ---
                $sql_pagos = "
                    SELECT SUM(monto) AS total_pagado
                    FROM pagos
                    WHERE cod_turista = $id_turista
                ";
                $pagado = $conexion->query($sql_pagos)->fetch_assoc()['total_pagado'] ?? 0;

                $total_pagado = floatval($pagado);
                $saldo_pendiente = $total_reservas - $total_pagado;

                $estado_pago = "";
                if (abs($saldo_pendiente) < 0.01) {
                    $estado_pago = "<p class='payment-status text-success'>✅ Pago completo</p>";
                    $saldo_pendiente = 0;
                } elseif ($saldo_pendiente > 0) {
                    $estado_pago = "<p class='payment-status text-warning'>⚠️ Falta por pagar</p>";
                } else {
                    $estado_pago = "<p class='payment-status text-danger'>💰 Sobrepago detectado</p>";
                }

                echo "<div class='summary mt-4'>";
                echo "<p><strong>Total Vuelos:</strong> \$" . number_format($total_vuelos, 2) . "</p>";
                echo "<p><strong>Total Hoteles:</strong> \$" . number_format($total_hoteles, 2) . "</p>";
                echo "<p><strong>Total Reservas:</strong> \$" . number_format($total_reservas, 2) . "</p>";
                echo "<p><strong>Total Pagado:</strong> \$" . number_format($total_pagado, 2) . "</p>";
                echo "<p><strong>Saldo Pendiente:</strong> <span class='" . ($saldo_pendiente > 0 ? "balance-negative" : "balance-positive") . "'>\$" . number_format(abs($saldo_pendiente), 2) . "</span></p>";
                echo $estado_pago;
                echo "</div>";

                echo "</div></div>";
            endwhile;
            ?>
        </div>
    </div>
</body>
</html>
