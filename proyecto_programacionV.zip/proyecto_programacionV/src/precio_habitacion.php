<?php
include("conexion.php");

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $resultado = mysqli_query($conn, "SELECT precio FROM habitaciones WHERE id = $id LIMIT 1");
    if ($fila = mysqli_fetch_assoc($resultado)) {
        echo $fila['precio'];
    } else {
        echo "0";
    }
} else {
    echo "0";
}
?>
