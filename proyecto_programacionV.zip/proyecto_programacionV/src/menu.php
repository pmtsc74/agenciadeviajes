<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>SkyExplorer Tours - Menú Principal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />

    <style>
        :root {
            --color-primary: #0d6efd;
            --color-bg-sidebar: rgba(0, 0, 0, 0.85);
            
            --color-bg-main-dark: rgba(18, 18, 18, 0.9);
            --color-text-light: #fff;
            --color-text-dark: #222;
            --transition-speed: 0.3s;
        }

        body {
            margin: 0;
            font-family: 'Inter', sans-serif;
            background: transparent;
            color: var(--color-text-light);
            overflow-x: hidden;
            transition: background-color var(--transition-speed);
        }

        #background-video {
            position: fixed;
            right: 0;
            bottom: 0;
            min-width: 100%;
            min-height: 100%;
            z-index: -1;
            object-fit: cover;
            filter: brightness(0.5);
        }

        .sidebar {
            position: fixed;
            top: 0; left: 0;
            height: 100vh;
            width: 280px;
            background-color: var(--color-bg-sidebar);
            padding: 1.5rem 1rem;
            box-shadow: 2px 0 10px rgb(0 0 0 / 0.5);
            overflow-y: auto;
            z-index: 1050;
            transition: background-color var(--transition-speed);
        }

        .sidebar h4 {
            color: var(--color-primary);
            font-weight: 600;
            font-size: 1.5rem;
            margin-bottom: 1rem;
            user-select: none;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .sidebar h4 i {
            font-size: 1.8rem;
        }

        .sidebar p {
            font-size: 0.95rem;
            margin-bottom: 1.2rem;
            color: #ddd;
            user-select: none;
        }

        .sidebar hr {
            border-color: #444;
            margin: 1rem 0;
        }

        .sidebar .text-light.small {
            text-transform: uppercase;
            font-weight: 600;
            font-size: 0.75rem;
            letter-spacing: 1px;
            margin-bottom: 0.5rem;
            color: #bbb;
        }

        .sidebar .nav-link {
            color: var(--color-text-light);
            font-size: 1rem;
            padding: 0.5rem 0;
            display: flex;
            align-items: center;
            gap: 0.6rem;
            border-radius: 0.3rem;
            transition: color var(--transition-speed), background-color var(--transition-speed), transform var(--transition-speed);
            user-select: none;
        }

        .sidebar .nav-link:hover,
        .sidebar .nav-link:focus {
            color: var(--color-primary);
            background-color: rgba(255 255 255 / 0.1);
            text-decoration: none;
            transform: translateX(6px);
            outline: none;
        }

        .main-content {
            margin-left: 280px;
            padding: 2.5rem 2rem;
            min-height: 100vh;
            background: var(--color-bg-main-light);
            color: var(--color-text-dark);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            box-shadow: inset 0 0 100px rgb(255 255 255 / 0.1);
            transition: background-color var(--transition-speed), color var(--transition-speed);
        }

        .main-content h2, .main-content p {
            text-shadow: 1px 1px 4px rgba(0,0,0,0.3);
        }

        .toggle-dark {
            position: fixed;
            top: 1rem;
            right: 1rem;
            z-index: 1100;
            background: transparent;
            border: none;
            cursor: pointer;
            color: var(--color-text-light);
            font-size: 1.8rem;
            transition: color var(--transition-speed);
        }

        .toggle-dark:focus {
            outline: 2px solid var(--color-primary);
            outline-offset: 2px;
        }

        body.dark-mode {
            background-color: #121212;
            color: var(--color-text-light);
        }

        body.dark-mode .sidebar {
            background-color: #111;
            color: var(--color-text-light);
        }

        body.dark-mode .sidebar hr {
            border-color: #555;
        }

        body.dark-mode .sidebar .nav-link:hover,
        body.dark-mode .sidebar .nav-link:focus {
            background-color: rgba(255 255 255 / 0.15);
            color: var(--color-primary);
        }

        body.dark-mode .main-content {
            background-color: var(--color-bg-main-dark);
            color: var(--color-text-light);
        }

        .stats-container {
            margin-top: 3rem;
            width: 100%;
            max-width: 900px;
            display: flex;
            gap: 1.5rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        .stat-card {
            flex: 1 1 250px;
            background: white;
            color: #222;
            border-radius: 0.6rem;
            padding: 1.8rem 1.5rem;
            box-shadow: 0 6px 20px rgb(0 0 0 / 0.15);
            transition: box-shadow 0.3s ease;
            user-select: none;
        }

        .stat-card:hover {
            box-shadow: 0 10px 30px rgb(0 0 0 / 0.25);
        }

        .stat-card h5 {
            font-weight: 600;
            margin-bottom: 0.8rem;
            display: flex;
            align-items: center;
            gap: 0.7rem;
            color: var(--color-primary);
        }

        .stat-card h5 i {
            font-size: 1.4rem;
        }

        .stat-card h2 {
            font-weight: 700;
            font-size: 2.6rem;
            margin: 0;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                padding: 1rem;
            }
            .main-content {
                margin-left: 0;
                padding: 1.5rem 1rem;
            }
            .stats-container {
                flex-direction: column;
                gap: 1rem;
            }
        }
    </style>
</head>
<body>

<video autoplay muted loop id="background-video">
    <source src="fondo_video.mp4" type="video/mp4">
    Tu navegador no soporta video HTML5.
</video>

<button class="toggle-dark" onclick="toggleDarkMode()">
    <i class="bi bi-moon-stars-fill" id="iconoModo"></i>
</button>

<nav class="sidebar">
    <h4><i class="bi bi-airplane-engines"></i> SkyExplorer</h4>
    <hr />
    <p><i class="bi bi-person-circle"></i> <?= htmlspecialchars($_SESSION['usuario']); ?></p>
    <a class="nav-link" href="registro_turista.php"><i class="bi bi-person-plus-fill"></i> Registrar Cliente</a>
    <a class="nav-link" href="listar_turistas.php"><i class="bi bi-people-fill"></i> Ver Clientes</a>
    <hr />
    <span class="text-light small">Hoteles</span>
    <a class="nav-link" href="hoteles.php"><i class="bi bi-building"></i> Ver Hoteles</a>
    <a class="nav-link" href="habitaciones.php"><i class="bi bi-door-open"></i> Habitaciones</a>
    <hr />
    <span class="text-light small">Reservas</span>
    <a class="nav-link" href="nueva_reserva.php"><i class="bi bi-calendar-plus"></i> Nueva Reservación</a>
    <a class="nav-link" href="listar_reservas.php"><i class="bi bi-journal-text"></i> Ver Reservas</a>
    <hr />
    <span class="text-light small">Restaurante</span>
   <a class="nav-link" href="/hotelrestaurante/restaurante/index.php"><i class="bi bi-receipt"></i> Órdenes</a>
    <hr />
    <span class="text-light small">Pagos</span>
    <a class="nav-link" href="registrar_pago.php"><i class="bi bi-cash-coin"></i> Registrar Pago</a>
    <a class="nav-link" href="generar_factura.php"><i class="bi bi-wallet2"></i> Ver Pagos</a>
    <hr />
    <span class="text-light small">Reportes</span>
    <a class="nav-link" href="reporte_turistas.php"><i class="bi bi-bar-chart-fill"></i> Clientes y Saldos</a>
    <a class="nav-link" href="reportes_avanzados.php"><i class="bi bi-graph-up"></i> Reportes Avanzados</a>
    <hr />
    <span class="text-light small">Configuración</span>
    <a class="nav-link" href="registro_usuario.php"><i class="bi bi-person-gear"></i> Registrar Usuario</a>
    <a class="nav-link" href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar sesión</a>
</nav>

<main class="main-content">
    <div class="d-flex flex-column align-items-center gap-4">
        <a href="#" class="btn btn-primary btn-lg shadow px-4">
            <i class="bi bi-airplane-fill me-2"></i> Bienvenido a SkyExplorer Tours
        </a>
        <a href="#" class="btn btn-outline-primary btn-lg shadow px-4">
            <i class="bi bi-stars me-2"></i> Disfruta la mejor experiencia de gestión turística. Tu viaje comienza aquí.
        </a>
    </div>

    <?php
    include("conexion.php");
    $reservas_activas = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM reserva_hotel WHERE estado='Activa'"))['total'];
    $habitaciones_ocupadas = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM habitaciones WHERE estado='Ocupada'"))['total'];
    $ingresos = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(monto) AS total FROM pagos"))['total'] ?? 0;
    ?>

    <section class="stats-container">
        <article class="stat-card">
            <h5><i class="bi bi-journal-check"></i> Reservas Activas</h5>
            <h2><?= $reservas_activas ?></h2>
        </article>

        <article class="stat-card">
            <h5><i class="bi bi-door-closed"></i> Habitaciones Ocupadas</h5>
            <h2><?= $habitaciones_ocupadas ?></h2>
        </article>

        <article class="stat-card">
            <h5><i class="bi bi-cash-coin"></i> Ingresos Totales</h5>
            <h2>$<?= number_format($ingresos, 2) ?></h2>
        </article>
    </section>
</main>

<script>
    function toggleDarkMode() {
        document.body.classList.toggle('dark-mode');
        const icon = document.getElementById('iconoModo');
        icon.classList.toggle('bi-moon-stars-fill');
        icon.classList.toggle('bi-brightness-high-fill');
    }
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
