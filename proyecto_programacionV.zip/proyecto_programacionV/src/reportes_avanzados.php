<?php
$conexion = new mysqli("localhost", "root", "", "agencia_viajes");
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$search = $_GET['search'] ?? '';
$order = $_GET['order'] ?? 'asc';
$order = strtolower($order) === 'desc' ? 'desc' : 'asc'; // seguridad básica
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Reporte Avanzado: Clientes con Saldos y Totales</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        /* Video de fondo */
        #video-background {
            position: fixed;
            right: 0;
            bottom: 0;
            min-width: 100%;
            min-height: 100%;
            width: auto;
            height: auto;
            z-index: -1;
            object-fit: cover;
            filter: brightness(0.5);
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: none;
            color: #212529;
        }

        /* Contenedor contenido principal */
        .content-container {
            position: relative;
            z-index: 1;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 40px;
            border-radius: 12px;
            max-width: 1100px;
            margin: 50px auto 70px auto;
            box-shadow: 0 8px 24px rgba(0,0,0,0.3);
        }

        h1.text-center {
            font-weight: 800;
            color: #003366;
            margin-bottom: 30px;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.4);
        }

        .table thead th {
            background-color: #0d6efd;
            color: white;
            cursor: pointer;
            user-select: none;
        }

        .balance-positive {
            color: green;
            font-weight: 700;
        }

        .balance-negative {
            color: red;
            font-weight: 700;
        }

        form .form-control, form .form-select {
            max-width: 300px;
        }

        /* Botones */
        .btn-primary {
            background-color: #0d6efd;
            border-color: #0d6efd;
        }

        .btn-primary:hover {
            background-color: #0b5ed7;
            border-color: #0a58ca;
        }
    </style>
</head>
<body>

<video autoplay muted loop id="video-background">
    <source src="fondo_video.mp4" type="video/mp4">
    Tu navegador no soporta video de fondo.
</video>

<div class="content-container">
    <h1 class="text-center">Reporte Avanzado: Clientes con Saldos y Totales</h1>
    
    <form method="GET" class="mb-4">
        <div class="row g-2 align-items-center">
            <div class="col-auto">
                <input type="text" name="search" class="form-control" placeholder="Buscar cliente..." value="<?php echo htmlspecialchars($search); ?>" />
            </div>
            <div class="col-auto">
                <select name="order" class="form-select">
                    <option value="asc" <?php if($order=='asc') echo 'selected'; ?>>Saldo Ascendente</option>
                    <option value="desc" <?php if($order=='desc') echo 'selected'; ?>>Saldo Descendente</option>
                </select>
            </div>
            <div class="col-auto">
                <button class="btn btn-primary">Filtrar</button>
                <a href="<?php echo $_SERVER['PHP_SELF']; ?>" class="btn btn-secondary ms-2">Resetear</a>
            </div>
        </div>
    </form>
    
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Cliente</th>
                <th>Total Reservado (USD)</th>
                <th>Total Pagado (USD)</th>
                <th>
                    <a href="?<?php
                        $newOrder = $order === 'asc' ? 'desc' : 'asc';
                        $query = http_build_query(['search'=>$search,'order'=>$newOrder]);
                        echo $query;
                    ?>" style="color: white; text-decoration:none;">
                    Saldo Pendiente (USD) <?php echo $order==='asc' ? '▲' : '▼'; ?>
                    </a>
                </th>
            </tr>
        </thead>
        <tbody>
            <?php
            $totalReservadoFinal = 0;
            $totalPagadoFinal = 0;
            $totalSaldoFinal = 0;

            $sql_turistas = "SELECT * FROM turistas WHERE CONCAT(nombre, ' ', apellidos) LIKE ?";
            $stmt = $conexion->prepare($sql_turistas);
            $likeSearch = "%$search%";
            $stmt->bind_param("s", $likeSearch);
            $stmt->execute();
            $res_turistas = $stmt->get_result();

            $clientes_data = [];

            while ($turista = $res_turistas->fetch_assoc()) {
                $id_turista = (int)$turista['cod_turista'];

                $sql_vuelos = "
                    SELECT SUM(v.precio) AS total_vuelo
                    FROM reserva_vuelo rv
                    LEFT JOIN vuelos v ON rv.num_vuelo = v.num_vuelo
                    WHERE rv.cod_turista = $id_turista
                ";
                $total_vuelos = floatval($conexion->query($sql_vuelos)->fetch_assoc()['total_vuelo'] ?? 0);

                $sql_hoteles = "
                    SELECT rh.fecha_llegada, rh.fecha_partida, hb.precio AS precio_noche
                    FROM reserva_hotel rh
                    LEFT JOIN habitaciones hb ON rh.habitacion_id = hb.id
                    WHERE rh.cod_turista = $id_turista
                ";
                $res_hoteles = $conexion->query($sql_hoteles);
                $total_hoteles = 0;
                while ($h = $res_hoteles->fetch_assoc()) {
                    $fecha_llegada = new DateTime($h['fecha_llegada']);
                    $fecha_partida = new DateTime($h['fecha_partida']);
                    $noches = $fecha_llegada->diff($fecha_partida)->days;
                    $precio_noche = floatval($h['precio_noche']);
                    $total_hoteles += $precio_noche * $noches;
                }

                $total_reservado = $total_vuelos + $total_hoteles;

                $sql_pagos = "SELECT SUM(monto) AS total_pagado FROM pagos WHERE cod_turista = $id_turista";
                $total_pagado = floatval($conexion->query($sql_pagos)->fetch_assoc()['total_pagado'] ?? 0);

                $saldo_pendiente = $total_reservado - $total_pagado;

                $clientes_data[] = [
                    'nombre' => $turista['nombre'] . ' ' . $turista['apellidos'],
                    'total_reservado' => $total_reservado,
                    'total_pagado' => $total_pagado,
                    'saldo_pendiente' => $saldo_pendiente,
                ];

                $totalReservadoFinal += $total_reservado;
                $totalPagadoFinal += $total_pagado;
                $totalSaldoFinal += $saldo_pendiente;
            }

            usort($clientes_data, function($a, $b) use ($order) {
                return ($order === 'asc') 
                    ? $a['saldo_pendiente'] <=> $b['saldo_pendiente'] 
                    : $b['saldo_pendiente'] <=> $a['saldo_pendiente'];
            });

            foreach ($clientes_data as $cliente) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($cliente['nombre']) . "</td>";
                echo "<td>$" . number_format($cliente['total_reservado'], 2) . "</td>";
                echo "<td>$" . number_format($cliente['total_pagado'], 2) . "</td>";
                $colorClass = $cliente['saldo_pendiente'] > 0 ? 'balance-negative' : 'balance-positive';
                echo "<td class='$colorClass'>$" . number_format($cliente['saldo_pendiente'], 2) . "</td>";
                echo "</tr>";
            }
            ?>
        </tbody>
        <tfoot>
            <tr>
                <th>Totales Finales</th>
                <th>$<?php echo number_format($totalReservadoFinal, 2); ?></th>
                <th>$<?php echo number_format($totalPagadoFinal, 2); ?></th>
                <th class="<?php echo ($totalSaldoFinal > 0) ? 'balance-negative' : 'balance-positive'; ?>">
                    $<?php echo number_format($totalSaldoFinal, 2); ?>
                </th>
            </tr>
        </tfoot>
    </table>
</div>

</body>
</html>
