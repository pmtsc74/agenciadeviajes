<?php
$conn = new mysqli("localhost", "root", "", "agencia_viajes");
$cod = intval($_GET['cod_turista'] ?? 0);

$vuelo = 0;
$result = $conn->query("SELECT v.precio FROM reserva_vuelo rv JOIN vuelos v ON rv.num_vuelo = v.num_vuelo WHERE rv.cod_turista = $cod LIMIT 1");
if ($row = $result->fetch_assoc()) $vuelo = floatval($row['precio']);

$hotel = 0;
$noches = 0;
$result = $conn->query("SELECT h.precio_noche, rh.fecha_llegada, rh.fecha_partida FROM reserva_hotel rh JOIN hoteles h ON rh.cod_hotel = h.cod_hotel WHERE rh.cod_turista = $cod LIMIT 1");
if ($row = $result->fetch_assoc()) {
    $inicio = new DateTime($row['fecha_llegada']);
    $fin = new DateTime($row['fecha_partida']);
    $noches = $inicio->diff($fin)->days;
    $hotel = floatval($row['precio_noche']) * $noches;
}

$total = $vuelo + $hotel;

echo json_encode([
    'precio_vuelo' => number_format($vuelo, 2),
    'total_hotel' => number_format($hotel, 2),
    'noches' => $noches,
    'total' => number_format($total, 2)
]);
?>
