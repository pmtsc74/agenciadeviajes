<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

include("conexion.php");

// Filtro de país
$pais = $_GET['pais'] ?? '';

// Obtener lista de países
$paises = mysqli_query($conn, "SELECT DISTINCT pais FROM hoteles ORDER BY pais ASC");
if (!$paises) die("Error al obtener países: " . mysqli_error($conn));

// Consulta de hoteles
$query = $pais 
    ? "SELECT * FROM hoteles WHERE pais = '$pais' ORDER BY categoria DESC" 
    : "SELECT * FROM hoteles ORDER BY pais ASC, categoria DESC";
$resultado = mysqli_query($conn, $query);
if (!$resultado) die("Error en consulta: " . mysqli_error($conn));
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Hoteles por País</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body.bg-hoteles {
            background-image: url('imagenes/fondos/hoteles.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }
        .container {
            background-color: rgba(255,255,255,0.95);
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 0 20px rgba(0,0,0,0.25);
        }
        .hotel-card img {
            height: 200px;
            object-fit: cover;
            width: 100%;
        }
        h3 {
            font-weight: bold;
            color: #333;
        }
    </style>
</head>
<body class="bg-hoteles">
<div class="container mt-5">
    <h3 class="mb-4">🌍 Hoteles por País</h3>

    <!-- Filtro por país -->
    <form method="GET" class="row mb-4">
        <div class="col-md-4">
            <select name="pais" class="form-select" onchange="this.form.submit()">
                <option value="">-- Todos los países --</option>
                <?php while ($p = mysqli_fetch_assoc($paises)): ?>
                    <option value="<?= htmlspecialchars($p['pais']) ?>" <?= $pais === $p['pais'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($p['pais']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
    </form>

    <!-- Lista de hoteles -->
    <div class="row">
        <?php while ($h = mysqli_fetch_assoc($resultado)): ?>
            <div class="col-md-4 mb-4">
                <div class="card hotel-card shadow-sm h-100">
                    <?php
                    $carpeta_imagenes = "imagenes/hoteles/";
                    $imagen_principal = $carpeta_imagenes . $h['cod_hotel'] . ".jpg";
                    $imagen_default = $carpeta_imagenes . "default.jpg";

                    if (!file_exists($imagen_principal)) {
                        $imagen_principal = $imagen_default;
                    }
                    ?>
                    <img src="<?= $imagen_principal . '?v=' . time() ?>" 
                         class="card-img-top" 
                         alt="Hotel <?= htmlspecialchars($h['nombre']) ?>">

                    <div class="card-body">
                        <h5 class="card-title"><?= htmlspecialchars($h['nombre']) ?></h5>
                        <p class="card-text">
                            📍 <?= htmlspecialchars($h['direccion']) ?>, <?= htmlspecialchars($h['ciudad']) ?><br>
                            📞 <?= htmlspecialchars($h['telefono']) ?><br>
                            ⭐ Categoría: <?= str_repeat('★', $h['categoria']) ?><br>
                            <a href="habitaciones.php?hotel=<?= $h['cod_hotel'] ?>" class="btn btn-sm btn-primary mt-2">
                                Ver Habitaciones
                            </a>
                        </p>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>
<!-- Botón Volver -->
<div class="text-center mt-4">
    <a href="menu.php" class="btn btn-secondary btn-lg">
        ← Volver al menú principal
    </a>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
