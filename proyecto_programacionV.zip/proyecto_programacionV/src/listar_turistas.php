<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

include("conexion.php");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Ver Clientes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body.bg-clientes {
            background-image: url('imagenes/fondos/clientes.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.95);
            padding: 2rem;
            border-radius: 20px;
            box-shadow: 0 0 20px rgba(0,0,0,0.2);
        }
        h3 {
            font-weight: bold;
            color: #333;
        }
    </style>
</head>
<body class="bg-clientes">
<div class="container mt-5">
    <h3 class="mb-4">📋 Listado de Clientes Registrados</h3>

    <table class="table table-striped table-bordered bg-white shadow-sm">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Apellidos</th>
                <th>Documento</th>
                <th>Email</th>
                <th>Teléfono</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $clientes = mysqli_query($conn, "SELECT * FROM turistas ORDER BY cod_turista DESC");
            while ($c = mysqli_fetch_assoc($clientes)):
            ?>
                <tr>
                    <td><?= $c['cod_turista'] ?></td>
                    <td><?= $c['nombre'] ?></td>
                    <td><?= $c['apellidos'] ?></td>
                    <td><?= $c['documento'] ?></td>
                    <td><?= $c['correo'] ?></td>
                    <td><?= $c['telefono'] ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body>
</html>
