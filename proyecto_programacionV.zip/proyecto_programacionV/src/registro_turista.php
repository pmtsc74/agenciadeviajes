<?php
include("conexion.php");
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['confirmar_pago'])) {
    // TURISTA
    $nombre = $_POST['nombre'];
    $apellidos = $_POST['apellidos'];
    $documento = $_POST['documento'];
    $correo = $_POST['correo'];
    $direccion = $_POST['direccion'];
    $telefono = $_POST['telefono'];

    // VUELO
    $num_vuelo = $_POST['num_vuelo'];
    $clase = $_POST['clase'];
    $fecha_salida = $_POST['fecha_salida'];
    $fecha_regreso = $_POST['fecha_regreso'];

    // Obtener precio vuelo
    $q1 = $conn->prepare("SELECT precio FROM vuelos WHERE num_vuelo = ?");
    $q1->bind_param("s", $num_vuelo);
    $q1->execute();
    $q1->bind_result($precio_vuelo);
    $q1->fetch();
    $q1->close();

    // Insertar turista
    $stmt = $conn->prepare("INSERT INTO turistas (nombre, apellidos, documento, correo, direccion, telefono) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $nombre, $apellidos, $documento, $correo, $direccion, $telefono);
    $stmt->execute();
    $cod_turista = $stmt->insert_id;
    $stmt->close();

    // Generar código de reserva vuelo
    $codigo_reserva_vuelo = strtoupper(substr($nombre, 0, 2) . substr($num_vuelo, -3) . rand(100, 999));

    // Insertar reserva vuelo
    $stmt2 = $conn->prepare("INSERT INTO reserva_vuelo (cod_turista, num_vuelo, clase, codigo_reserva, fecha_salida, fecha_regreso) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt2->bind_param("isssss", $cod_turista, $num_vuelo, $clase, $codigo_reserva_vuelo, $fecha_salida, $fecha_regreso);
    $stmt2->execute();
    $stmt2->close();

    $mensaje = "<strong>Reserva de vuelo completada</strong><br>Código Vuelo: $codigo_reserva_vuelo<br>Total estimado: B/. $precio_vuelo";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registrar Cliente - Agencia de Viajes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body.bg-viaje {
            background-image: url('imagenes/fondos/registro.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }
        .card {
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
        }
        .form-control, .form-select {
            border-radius: 10px;
        }
        .card-header h4 {
            font-weight: bold;
            letter-spacing: 1px;
        }
    </style>
</head>
<body class="bg-viaje">
<div class="container mt-5">
    <div class="card shadow-lg">
        <div class="card-header bg-dark text-white text-center">
            <h4><i class="bi bi-person-plus"></i> Registro de Cliente y Reserva</h4>
        </div>
        <div class="card-body">
            <?php if ($mensaje) echo "<div class='alert alert-success'>$mensaje</div>"; ?>
            <form method="POST" class="px-3">
                <h5 class="mb-3">🧍 Datos del Turista</h5>
                <div class="row mb-3">
                    <div class="col-md-6"><input name="nombre" class="form-control" placeholder="Nombre" required></div>
                    <div class="col-md-6"><input name="apellidos" class="form-control" placeholder="Apellidos" required></div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6"><input name="documento" class="form-control" placeholder="Documento (cédula/pasaporte)" required></div>
                    <div class="col-md-6"><input name="correo" type="email" class="form-control" placeholder="Correo electrónico" required></div>
                </div>
                <input name="direccion" class="form-control mb-3" placeholder="Dirección" required>
                <input name="telefono" class="form-control mb-3" placeholder="Teléfono" required>

                <h5 class="mb-3">✈️ Información del Vuelo</h5>
                <select name="num_vuelo" class="form-select mb-3" required>
                    <option disabled selected>-- Selecciona un vuelo --</option>
                    <?php
                    $vuelos = $conn->query("SELECT * FROM vuelos");
                    while ($v = $vuelos->fetch_assoc()) {
                        echo "<option value='{$v['num_vuelo']}'>
                            {$v['empresa']} | {$v['origen']} → {$v['destino']} | B/. {$v['precio']}
                        </option>";
                    }
                    ?>
                </select>

                <div class="row mb-3">
                    <div class="col"><label>Fecha de salida</label><input type="date" name="fecha_salida" class="form-control" required></div>
                    <div class="col"><label>Fecha de regreso</label><input type="date" name="fecha_regreso" class="form-control" required></div>
                </div>

                <label>Clase de vuelo</label>
                <select name="clase" class="form-select mb-4" required>
                    <option value="turista">Turista</option>
                    <option value="primera">Primera</option>
                </select>

                <div class="d-grid mb-3">
                    <button type="submit" name="confirmar_pago" class="btn btn-success btn-lg">✅ Confirmar Reserva</button>
                </div>
            </form>

            <div class="text-center">
                <a href="menu.php" class="btn btn-outline-secondary mt-3">← Volver al Menú Principal</a>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap Icons (opcional para íconos) -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</body>
</html>
