-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 25-09-2025 a las 16:50:51
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `agencia_viajes`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `destinos`
--

CREATE TABLE `destinos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `pais` varchar(100) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `facturas`
--

CREATE TABLE `facturas` (
  `id` int(11) NOT NULL,
  `id_reserva` int(11) NOT NULL,
  `id_reserva_vuelo` int(11) DEFAULT NULL,
  `id_reserva_hotel` int(11) DEFAULT NULL,
  `tipo_reserva` enum('vuelo','hotel') NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp(),
  `monto` decimal(10,2) NOT NULL,
  `estado` enum('pendiente','pagada','anulada') DEFAULT 'pendiente',
  `cliente` varchar(150) NOT NULL,
  `nombre_cliente` varchar(150) DEFAULT NULL,
  `destino` varchar(255) DEFAULT NULL,
  `nombre_hotel` varchar(255) DEFAULT NULL,
  `destino_viaje` varchar(255) DEFAULT NULL,
  `hotel_hospedaje` varchar(255) DEFAULT NULL,
  `hotel_nombre` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `facturas`
--

INSERT INTO `facturas` (`id`, `id_reserva`, `id_reserva_vuelo`, `id_reserva_hotel`, `tipo_reserva`, `fecha`, `monto`, `estado`, `cliente`, `nombre_cliente`, `destino`, `nombre_hotel`, `destino_viaje`, `hotel_hospedaje`, `hotel_nombre`) VALUES
(2, 0, NULL, NULL, 'vuelo', '2025-07-11 02:27:04', 2380.00, 'pagada', 'Nicole González', NULL, NULL, NULL, NULL, NULL, NULL),
(3, 0, NULL, NULL, 'vuelo', '2025-07-11 02:51:18', 4850.00, 'pagada', 'Andres Miranda', NULL, NULL, NULL, NULL, NULL, NULL),
(9, 0, NULL, NULL, 'vuelo', '2025-07-11 08:29:29', 2420.00, 'pagada', 'Edgar Yoel Trotman Archibold', NULL, NULL, NULL, NULL, NULL, NULL),
(10, 0, NULL, NULL, 'vuelo', '2025-07-11 14:28:49', 1580.00, 'pagada', 'Joiner Arauz', NULL, NULL, NULL, NULL, NULL, NULL),
(11, 0, NULL, NULL, 'vuelo', '2025-07-11 15:10:24', 1380.00, 'pagada', 'Lisbeth  De Vargas ', NULL, NULL, NULL, NULL, NULL, NULL),
(12, 0, NULL, NULL, 'vuelo', '2025-07-11 15:58:10', 3950.00, 'pagada', 'Ivan  Espinoza', NULL, NULL, NULL, NULL, NULL, NULL),
(13, 0, NULL, NULL, 'vuelo', '2025-07-11 16:06:24', 1180.00, 'pagada', 'Alexis  Flores', NULL, NULL, NULL, NULL, NULL, NULL),
(14, 0, NULL, NULL, 'vuelo', '2025-07-12 21:11:48', 2330.00, 'pagada', 'Alexis  Flores', NULL, NULL, NULL, NULL, NULL, NULL),
(15, 0, NULL, NULL, 'vuelo', '2025-08-18 14:33:35', 4850.00, 'pagada', 'Andres Miranda', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `habitaciones`
--

CREATE TABLE `habitaciones` (
  `id` int(11) NOT NULL,
  `cod_hotel` int(11) NOT NULL,
  `numero_habitacion` varchar(10) NOT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `estado` enum('Disponible','Ocupada','Mantenimiento') DEFAULT 'Disponible'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `habitaciones`
--

INSERT INTO `habitaciones` (`id`, `cod_hotel`, `numero_habitacion`, `tipo`, `precio`, `estado`) VALUES
(2, 1, '101', 'Suite', 250.00, 'Ocupada'),
(3, 1, '102', 'Deluxe', 200.00, 'Ocupada'),
(4, 1, '103', 'Doble', 150.00, 'Disponible'),
(5, 1, '104', 'Individual', 100.00, 'Disponible'),
(6, 1, '105', 'Familiar', 180.00, 'Disponible'),
(7, 2, '201', 'Deluxe', 200.00, 'Disponible'),
(8, 2, '202', 'Doble', 150.00, 'Disponible'),
(9, 2, '203', 'Individual', 100.00, 'Ocupada'),
(10, 2, '204', 'Familiar', 180.00, 'Ocupada'),
(11, 3, '301', 'Doble', 150.00, 'Disponible'),
(12, 3, '302', 'Individual', 100.00, 'Disponible'),
(13, 3, '303', 'Familiar', 180.00, 'Disponible'),
(14, 4, '401', 'Doble', 150.00, 'Disponible'),
(15, 4, '402', 'Individual', 100.00, 'Disponible'),
(16, 5, '501', 'Suite', 250.00, 'Ocupada'),
(17, 5, '502', 'Deluxe', 200.00, 'Disponible'),
(18, 5, '503', 'Doble', 150.00, 'Disponible'),
(19, 5, '504', 'Individual', 100.00, 'Disponible'),
(20, 5, '505', 'Familiar', 180.00, 'Disponible'),
(21, 6, '601', 'Deluxe', 200.00, 'Ocupada'),
(22, 6, '602', 'Doble', 150.00, 'Disponible'),
(23, 6, '603', 'Individual', 100.00, 'Disponible'),
(24, 6, '604', 'Familiar', 180.00, 'Disponible'),
(25, 7, '701', 'Doble', 150.00, 'Ocupada'),
(26, 7, '702', 'Individual', 100.00, 'Disponible'),
(27, 7, '703', 'Familiar', 180.00, 'Disponible'),
(28, 8, '801', 'Doble', 150.00, 'Disponible'),
(29, 8, '802', 'Individual', 100.00, 'Disponible'),
(30, 9, '901', 'Suite', 250.00, 'Disponible'),
(31, 9, '902', 'Deluxe', 200.00, 'Disponible'),
(32, 9, '903', 'Doble', 150.00, 'Disponible'),
(33, 9, '904', 'Individual', 100.00, 'Disponible'),
(34, 9, '905', 'Familiar', 180.00, 'Disponible'),
(35, 10, '1001', 'Deluxe', 200.00, 'Disponible'),
(36, 10, '1002', 'Doble', 150.00, 'Disponible'),
(37, 10, '1003', 'Individual', 100.00, 'Disponible'),
(38, 10, '1004', 'Familiar', 180.00, 'Disponible'),
(39, 11, '1101', 'Doble', 150.00, 'Disponible'),
(40, 11, '1102', 'Individual', 100.00, 'Disponible'),
(41, 11, '1103', 'Familiar', 180.00, 'Disponible'),
(42, 12, '1201', 'Doble', 150.00, 'Disponible'),
(43, 12, '1202', 'Individual', 100.00, 'Disponible');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hoteles`
--

CREATE TABLE `hoteles` (
  `cod_hotel` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `ciudad` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `plazas_disponibles` int(11) DEFAULT NULL,
  `precio_noche` decimal(10,2) DEFAULT NULL,
  `categoria` int(11) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `pais` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `hoteles`
--

INSERT INTO `hoteles` (`cod_hotel`, `nombre`, `direccion`, `ciudad`, `telefono`, `plazas_disponibles`, `precio_noche`, `categoria`, `estado`, `pais`) VALUES
(1, 'Hotel Bogotá Center', 'Av. Caracas #123', 'Bogota', '+57 1 365-0321', 40, 85.00, 5, 'Activo', 'Colombia'),
(2, 'Hotel Buenos Aires Plaza', 'Calle Florida 456', 'Buenos Aires', '+54 261 331-2349', 50, 120.00, 4, 'Activo', 'Argentina'),
(3, 'Hotel Rio Mar', 'Av. Atlántico 789', 'Brasilia', '+55 11 2055-3277', 60, 110.00, 3, 'Activo', 'Brasil'),
(4, 'Alvear Palace Hotel', 'Av. Alvear 1891, Recoleta', 'Buenos Aires', '+54 11 4808-2100', 100, 450.00, 2, 'Activo', 'Argentina'),
(5, 'NH Mendoza Cordillera', 'Av. España 1324', 'Mendoza', '+54 261 441-6464', 80, 120.00, 5, 'Activo', 'Argentina'),
(6, 'Hotel Tres Reyes', 'Av. 12 de Octubre 135, Centro', 'Bariloche', '+54 294 442-2985', 60, 90.00, 4, 'Activo', 'Argentina'),
(7, 'Copacabana Palace', 'Av. Atlântica 1702, Copacabana', 'Río de Janeiro', '+55 21 2548-7070', 120, 500.00, 3, 'Activo', 'Brasil'),
(8, 'Hotel Unique', 'Av. Brigadeiro Luís Antônio 4700', 'São Paulo', '+55 11 3055-4700', 90, 400.00, 2, 'Activo', 'Brasil'),
(9, 'Pousada Colonial', 'R. Direita do Santo Antônio 368', 'Salvador', '+55 71 3241-2166', 40, 80.00, 5, 'Activo', 'Brasil'),
(10, 'Hotel Casa San Agustín', 'Calle de la Universidad #36-44', 'Cartagena', '+57 5 681-0000', 50, 420.00, 4, 'Activo', 'Colombia'),
(11, 'Hotel Estelar Milla de Oro', 'Cra. 42 #5 sur-130', 'Medellín', '+57 4 369-6300', 70, 130.00, 3, 'Activo', 'Colombia'),
(12, 'Hotel Tequendama Bogotá', 'Carrera 10 #26-21', 'Bogotá', '+57 1 382-0300', 150, 110.00, 2, 'Activo', 'Colombia');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagos`
--

CREATE TABLE `pagos` (
  `id_pago` int(11) NOT NULL,
  `cod_turista` int(11) DEFAULT NULL,
  `id_reserva` int(11) DEFAULT NULL,
  `metodo_pago` varchar(50) DEFAULT NULL,
  `monto` decimal(10,2) DEFAULT NULL,
  `fecha_pago` date DEFAULT NULL,
  `numero_tarjeta` varchar(25) DEFAULT NULL,
  `banco` varchar(50) DEFAULT NULL,
  `numero_transferencia` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pagos`
--

INSERT INTO `pagos` (`id_pago`, `cod_turista`, `id_reserva`, `metodo_pago`, `monto`, `fecha_pago`, `numero_tarjeta`, `banco`, `numero_transferencia`) VALUES
(13, 14, NULL, 'Efectivo', 2380.00, '2025-07-10', NULL, '', ''),
(14, 15, NULL, 'Efectivo', 4850.00, '2025-07-10', NULL, '', ''),
(20, 16, NULL, 'Efectivo', 2420.00, '2025-07-11', NULL, '', ''),
(21, 17, NULL, 'Efectivo', 1580.00, '2025-07-11', NULL, '', ''),
(22, 18, NULL, 'Efectivo', 1380.00, '2025-07-11', NULL, '', ''),
(23, 19, NULL, 'Efectivo', 3950.00, '2025-07-11', NULL, '', ''),
(24, 20, NULL, 'Efectivo', 1180.00, '2025-07-11', NULL, '', ''),
(25, 20, NULL, 'Efectivo', 2330.00, '2025-07-12', NULL, '', ''),
(26, 15, NULL, 'Efectivo', 4850.00, '2025-08-18', NULL, '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reserva_hotel`
--

CREATE TABLE `reserva_hotel` (
  `id` int(11) NOT NULL,
  `cod_turista` int(11) NOT NULL,
  `cod_hotel` int(11) NOT NULL,
  `habitacion_id` int(11) DEFAULT NULL,
  `regimen` varchar(30) DEFAULT NULL,
  `fecha_llegada` date DEFAULT NULL,
  `fecha_partida` date DEFAULT NULL,
  `codigo_reserva` varchar(20) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `estado` enum('Activa','Finalizada','Cancelada') DEFAULT 'Activa',
  `adultos` int(11) DEFAULT 1,
  `ninos` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `reserva_hotel`
--

INSERT INTO `reserva_hotel` (`id`, `cod_turista`, `cod_hotel`, `habitacion_id`, `regimen`, `fecha_llegada`, `fecha_partida`, `codigo_reserva`, `total`, `estado`, `adultos`, `ninos`) VALUES
(4, 14, 2, 10, 'completa', '2025-07-15', '2025-07-25', 'YR6EKT', 1800.00, 'Activa', 2, 2),
(5, 15, 1, 2, 'completa', '2025-07-13', '2025-07-31', '4LC9P9', 4500.00, 'Activa', 1, 0),
(6, 16, 7, 25, 'solo alojamiento', '2025-07-13', '2025-07-25', 'GHPELN', 1800.00, 'Activa', 2, 0),
(7, 17, 2, 9, 'media', '2025-07-15', '2025-07-25', 'WGA4AL', 1000.00, 'Activa', 1, 0),
(8, 18, 6, 21, 'completa', '2025-07-13', '2025-07-17', 'LOKU00', 800.00, 'Activa', 2, 0),
(9, 19, 1, 3, 'completa', '2025-07-12', '2025-07-30', 'ZOGV7O', 3600.00, 'Activa', 2, 0),
(10, 20, 2, 8, 'media', '2025-07-13', '2025-07-17', 'BCJOXI', 600.00, 'Cancelada', 1, 0),
(11, 20, 5, 16, 'completa', '2025-07-21', '2025-07-28', 'PY8GK0', 1750.00, 'Activa', 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reserva_vuelo`
--

CREATE TABLE `reserva_vuelo` (
  `id` int(11) NOT NULL,
  `cod_turista` int(11) NOT NULL,
  `num_vuelo` varchar(10) NOT NULL,
  `clase` varchar(20) DEFAULT NULL,
  `codigo_reserva` varchar(20) DEFAULT NULL,
  `fecha_salida` date DEFAULT NULL,
  `fecha_regreso` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `reserva_vuelo`
--

INSERT INTO `reserva_vuelo` (`id`, `cod_turista`, `num_vuelo`, `clase`, `codigo_reserva`, `fecha_salida`, `fecha_regreso`) VALUES
(3, 14, 'ARG456', 'turista', 'NI456339', '2025-07-14', '2025-07-25'),
(4, 15, 'COL123', 'turista', 'AN123383', '2025-07-13', '2025-07-31'),
(5, 16, 'BRA789', 'turista', 'ED789525', '2025-07-12', '2025-07-25'),
(6, 17, 'ARG456', 'turista', 'JO456922', '2025-07-14', '2025-07-25'),
(7, 18, 'ARG456', 'primera', 'LI456262', '2025-07-12', '2025-07-18'),
(8, 19, 'COL123', 'primera', 'IV123220', '2025-07-12', '2025-07-30'),
(9, 20, 'ARG456', 'primera', 'AL456901', '2025-07-12', '2025-07-19');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sucursales`
--

CREATE TABLE `sucursales` (
  `cod_sucursal` int(11) NOT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `sucursales`
--

INSERT INTO `sucursales` (`cod_sucursal`, `direccion`, `telefono`) VALUES
(1, 'Sucursal Panamá Centro', '6000-0001'),
(2, 'Sucursal David', '6777-0002');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `turistas`
--

CREATE TABLE `turistas` (
  `cod_turista` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `apellidos` varchar(100) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `documento` varchar(30) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `turistas`
--

INSERT INTO `turistas` (`cod_turista`, `id_usuario`, `nombre`, `apellidos`, `direccion`, `telefono`, `documento`, `correo`) VALUES
(14, 0, 'Nicole', 'González', 'Veraguas', '+50766020145', '4-231-9853', 'gonzalezni90@gmail.com'),
(15, 0, 'Andres', 'Miranda', 'David', '+50765248745', '4-623-2176', 'miarandaandres20@gmail.com'),
(16, 0, 'Edgar Yoel', 'Trotman Archibold', 'Alto de Lagos - David', '+50767234569', '12-654-2312', 'yoeltrotman22@gmail.com'),
(17, 0, 'Joiner', 'Arauz', 'David', '+50768874302', '4-234-1298', 'joiner2025@gmail.com'),
(18, 0, 'Lisbeth ', 'De Vargas ', 'David', '6566-0099', '4-000-009', 'lisbeth.vargas@unachi.ac.pa'),
(19, 0, 'Ivan ', 'Espinoza', 'Las Lomas', '6168-1891', '4-0009-0099', 'ivan.espinoza@unachi.ac.pa'),
(20, 0, 'Alexis ', 'Flores', 'David', '7098-0987', '4-111-0099', 'alexis.flores@unachi.ac.pa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre_completo` varchar(100) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `rol` varchar(20) DEFAULT 'Administrador',
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre_completo`, `username`, `password`, `correo`, `telefono`, `rol`, `creado_en`) VALUES
(1, 'Sandra Lezcano', '1-719-486', '$2y$10$utrEoSaIQRjUqEZGBy9hyewO6GMrm6o5zi0vgxjRD1/kOHcYNU39u', 'jmescalante@gmail.com', '67432190', 'Usuario', '2025-06-11 19:33:30'),
(2, 'Alberto Escalante', '1-26-372', '$2y$10$wLNRDKod49UQu5r.iSipkuiNausFP62h10.E4WaEASkmPSEWTLZda', 'jmescalante@gmail.com', '63722614', 'Usuario', '2025-06-11 20:01:41'),
(3, 'nicole gonzalez', '12-719-539', '$2y$10$iLKHyaeWWtby1WJlOCzC/uvQwHmwWXWYmwx6VAVY9CzvO16OPDSxm', 'jgfreses@gmail.com', '6543213', 'Usuario', '2025-06-11 20:11:11'),
(5, 'Wilfredo Rios', '4-678-4532', '$2y$10$415RetcDPeWJLJEHWFMit./AXjcoCtjSjYTBNyneN/4yA/1YHkEUm', 'rios2025@gmail.com', '67543298', 'Usuario', '2025-06-19 00:02:11'),
(6, 'Jean Marcos Escalante', '4-234-1212', '$2y$10$et9xJr3oehtZJsByI/mi9O0m35GHKK4GtG4xCYqLwOnS5Qlum5uCC', 'jmescalante@gmail.com', '67543467', 'Administrador', '2025-07-01 13:12:19'),
(7, 'Rosibel Montero', '4-666-9090', '$2y$10$0EWjAfHqCLWC5CsZPN0Ua.fhXbxiNE8T1Mxjx5SNlUvOYrJXwnxLS', 'jmescalante@gmail.com', '67543298', 'Usuario', '2025-07-02 00:40:05'),
(8, 'Alexi Abrego', '12-708-1107', '$2y$10$jlT2gqk98dZmNkvWTBrggeJy0l1lyjGgV4SnXUe.glAepNhxub2p2', 'arialexis0999@gmail.com', '+50764220539', 'Usuario', '2025-07-10 18:45:40'),
(9, 'alberto gonzalez', '1-36-372', '$2y$10$1UmnFCgOxzQ4yI.TISP/d.babyJ54Yqf6W2pdGWeGD0Tcx7bZc6sC', 'jmescalante@gmail.com', '65437654', 'Usuario', '2025-08-18 14:25:37'),
(10, 'jaime diaz', '8-123-456', '$2y$10$PClDdIIKc8WTapE5S/EHgu/GY8ofz8tet9YYrQX4XNexdFPOzYjK.', 'jaimetupapidiaz@gmail.com', '68951214', 'Usuario', '2025-09-02 14:38:52'),
(11, 'Rosibel Montero', '1-26-373', '$2y$10$6CUi.I10Xj0Hd0Hw2jTogu.tQYMvmL6V4FjM.ASOe/kcnZjrbNWuy', 'jmescalante@gmail.com', '67543242', 'Usuario', '2025-09-10 01:29:55'),
(12, 'Jhayco Escalante', '12-715-829', '$2y$10$lYh.8dc4NAlQYKK3S1F0BOocrp/MQ9QcOHBtCAs2QD0aEy0JVzNF.', 'jmescalante@gmail.com', '67543212', 'Usuario', '2025-09-17 01:41:13');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vuelos`
--

CREATE TABLE `vuelos` (
  `num_vuelo` varchar(10) NOT NULL,
  `origen` varchar(100) DEFAULT NULL,
  `destino` varchar(100) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `empresa` varchar(100) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `cod_sucursal` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `vuelos`
--

INSERT INTO `vuelos` (`num_vuelo`, `origen`, `destino`, `fecha`, `hora`, `empresa`, `precio`, `cod_sucursal`) VALUES
('ARG456', 'Panamá', 'Argentina', '2025-07-12', '09:30:00', 'Copa Airlines', 580.00, 1),
('BRA789', 'Panamá', 'Brasil', '2025-07-15', '10:15:00', 'LATAM', 620.00, 1),
('COL123', 'Panamá', 'Colombia', '2025-07-10', '08:00:00', 'Avianca', 350.00, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `destinos`
--
ALTER TABLE `destinos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `facturas`
--
ALTER TABLE `facturas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `habitaciones`
--
ALTER TABLE `habitaciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cod_hotel` (`cod_hotel`);

--
-- Indices de la tabla `hoteles`
--
ALTER TABLE `hoteles`
  ADD PRIMARY KEY (`cod_hotel`);

--
-- Indices de la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD PRIMARY KEY (`id_pago`),
  ADD KEY `id_reserva` (`id_reserva`),
  ADD KEY `fk_pago_turista` (`cod_turista`);

--
-- Indices de la tabla `reserva_hotel`
--
ALTER TABLE `reserva_hotel`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cod_hotel` (`cod_hotel`),
  ADD KEY `habitacion_id` (`habitacion_id`),
  ADD KEY `fk_rh_turista` (`cod_turista`);

--
-- Indices de la tabla `reserva_vuelo`
--
ALTER TABLE `reserva_vuelo`
  ADD PRIMARY KEY (`cod_turista`,`num_vuelo`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `num_vuelo` (`num_vuelo`);

--
-- Indices de la tabla `sucursales`
--
ALTER TABLE `sucursales`
  ADD PRIMARY KEY (`cod_sucursal`);

--
-- Indices de la tabla `turistas`
--
ALTER TABLE `turistas`
  ADD PRIMARY KEY (`cod_turista`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indices de la tabla `vuelos`
--
ALTER TABLE `vuelos`
  ADD PRIMARY KEY (`num_vuelo`),
  ADD KEY `cod_sucursal` (`cod_sucursal`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `destinos`
--
ALTER TABLE `destinos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `facturas`
--
ALTER TABLE `facturas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `habitaciones`
--
ALTER TABLE `habitaciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT de la tabla `hoteles`
--
ALTER TABLE `hoteles`
  MODIFY `cod_hotel` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `pagos`
--
ALTER TABLE `pagos`
  MODIFY `id_pago` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT de la tabla `reserva_hotel`
--
ALTER TABLE `reserva_hotel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `reserva_vuelo`
--
ALTER TABLE `reserva_vuelo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `sucursales`
--
ALTER TABLE `sucursales`
  MODIFY `cod_sucursal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `turistas`
--
ALTER TABLE `turistas`
  MODIFY `cod_turista` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `habitaciones`
--
ALTER TABLE `habitaciones`
  ADD CONSTRAINT `habitaciones_ibfk_1` FOREIGN KEY (`cod_hotel`) REFERENCES `hoteles` (`cod_hotel`);

--
-- Filtros para la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD CONSTRAINT `fk_pago_turista` FOREIGN KEY (`cod_turista`) REFERENCES `turistas` (`cod_turista`) ON DELETE CASCADE,
  ADD CONSTRAINT `pagos_ibfk_1` FOREIGN KEY (`cod_turista`) REFERENCES `turistas` (`cod_turista`),
  ADD CONSTRAINT `pagos_ibfk_2` FOREIGN KEY (`id_reserva`) REFERENCES `reserva_hotel` (`id`);

--
-- Filtros para la tabla `reserva_hotel`
--
ALTER TABLE `reserva_hotel`
  ADD CONSTRAINT `fk_rh_turista` FOREIGN KEY (`cod_turista`) REFERENCES `turistas` (`cod_turista`) ON DELETE CASCADE,
  ADD CONSTRAINT `reserva_hotel_ibfk_2` FOREIGN KEY (`cod_hotel`) REFERENCES `hoteles` (`cod_hotel`),
  ADD CONSTRAINT `reserva_hotel_ibfk_3` FOREIGN KEY (`habitacion_id`) REFERENCES `habitaciones` (`id`);

--
-- Filtros para la tabla `reserva_vuelo`
--
ALTER TABLE `reserva_vuelo`
  ADD CONSTRAINT `reserva_vuelo_ibfk_1` FOREIGN KEY (`cod_turista`) REFERENCES `turistas` (`cod_turista`),
  ADD CONSTRAINT `reserva_vuelo_ibfk_2` FOREIGN KEY (`num_vuelo`) REFERENCES `vuelos` (`num_vuelo`);

--
-- Filtros para la tabla `vuelos`
--
ALTER TABLE `vuelos`
  ADD CONSTRAINT `vuelos_ibfk_1` FOREIGN KEY (`cod_sucursal`) REFERENCES `sucursales` (`cod_sucursal`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
