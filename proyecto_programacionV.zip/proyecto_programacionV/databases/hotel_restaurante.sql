-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 25-09-2025 a las 16:51:08
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `hotel_restaurante`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `nombre`, `email`, `telefono`) VALUES
(1, 'Ana García', 'ana@example.com', '5551002000'),
(2, 'Marco Escalante', 'marco.escalante@unachi.ac.pa', '68874302'),
(3, 'Iván Espinoza', 'rodrigo.espinoza@unachi.ac.pa', '61681891');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menu`
--

CREATE TABLE `menu` (
  `id_plato` int(11) NOT NULL,
  `nombre_plato` varchar(100) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `categoria` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menus_paises`
--

CREATE TABLE `menus_paises` (
  `id_menu` int(11) NOT NULL,
  `pais` varchar(50) NOT NULL,
  `categoria` varchar(50) NOT NULL,
  `nombre_plato` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL,
  `imagen` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `menus_paises`
--

INSERT INTO `menus_paises` (`id_menu`, `pais`, `categoria`, `nombre_plato`, `descripcion`, `precio`, `imagen`) VALUES
(1, 'Argentina', 'Plato Principal', 'Asado', 'Corte premium de carne asada a la parrilla con chimichurri', 25.99, NULL),
(2, 'Argentina', 'Plato Principal', 'Empanadas Criollas', '6 unidades de empanadas de carne cortada a cuchillo', 12.50, NULL),
(3, 'Argentina', 'Bebida', 'Malbec', 'Copa de vino Malbec de Mendoza', 8.75, NULL),
(4, 'Argentina', 'Bebida', 'Fernet con Coca', 'Trago tradicional argentino', 7.50, NULL),
(5, 'Argentina', 'Postre', 'Dulce de Leche Pancakes', 'Panqueques rellenos de dulce de leche con nuez', 9.99, NULL),
(6, 'Brasil', 'Plato Principal', 'Feijoada', 'Estofado de frijoles negros con carnes, acompañado de arroz y farofa', 18.99, NULL),
(7, 'Brasil', 'Plato Principal', 'Moqueca de Camarão', 'Guiso de camarones con aceite de dendê y leche de coco', 22.50, NULL),
(8, 'Brasil', 'Bebida', 'Caipirinha', 'Coctel tradicional con cachaça, limón y azúcar', 9.50, NULL),
(9, 'Brasil', 'Bebida', 'Guaraná Antarctica', 'Refresco brasileño tradicional', 4.50, NULL),
(10, 'Brasil', 'Postre', 'Brigadeiro', 'Bolitas de chocolate con leche condensada', 6.99, NULL),
(11, 'Colombia', 'Plato Principal', 'Bandeja Paisa', 'Frijoles, arroz, chicharrón, carne molida, chorizo, huevo y aguacate', 19.99, NULL),
(12, 'Colombia', 'Plato Principal', 'Ajiaco Santafereño', 'Sopa de pollo con tres tipos de papa y crema de leche', 16.50, NULL),
(13, 'Colombia', 'Bebida', 'Aguardiente', 'Licor típico colombiano', 7.50, NULL),
(14, 'Colombia', 'Bebida', 'Lulada', 'Bebida refrescante de lulo', 5.50, NULL),
(15, 'Colombia', 'Postre', 'Postre de Natas', 'Postre tradicional a base de leche', 7.99, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagos`
--

CREATE TABLE `pagos` (
  `id_pago` int(11) NOT NULL,
  `tipo_pago` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `id_pedido` int(11) NOT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `nombre_plato` varchar(100) NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL,
  `cantidad` int(11) NOT NULL DEFAULT 1,
  `pais` varchar(50) NOT NULL,
  `tipo_pago` varchar(20) NOT NULL,
  `fecha_pedido` datetime DEFAULT current_timestamp(),
  `total` decimal(10,2) DEFAULT NULL,
  `estado` enum('pendiente','completado','cancelado') DEFAULT 'pendiente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`id_pedido`, `id_cliente`, `nombre_plato`, `precio_unitario`, `cantidad`, `pais`, `tipo_pago`, `fecha_pedido`, `total`, `estado`) VALUES
(1, 3, 'Trago tradicional Argentino', 7.50, 1, 'Argentina', 'Efectivo', '2025-07-10 13:51:18', 7.00, 'pendiente'),
(2, 1, 'Carnes frías', 20.00, 1, 'Argentina', 'Efectivo', '2025-07-11 10:17:26', 20.00, 'pendiente'),
(3, 1, 'Carnes frías', 500.00, 2, 'Argentina', 'Efectivo', '2025-07-11 11:25:51', 1000.00, 'pendiente');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id_cliente`);

--
-- Indices de la tabla `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id_plato`);

--
-- Indices de la tabla `menus_paises`
--
ALTER TABLE `menus_paises`
  ADD PRIMARY KEY (`id_menu`);

--
-- Indices de la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD PRIMARY KEY (`id_pago`);

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id_pedido`),
  ADD KEY `id_cliente` (`id_cliente`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `menu`
--
ALTER TABLE `menu`
  MODIFY `id_plato` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `menus_paises`
--
ALTER TABLE `menus_paises`
  MODIFY `id_menu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `pagos`
--
ALTER TABLE `pagos`
  MODIFY `id_pago` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id_pedido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
